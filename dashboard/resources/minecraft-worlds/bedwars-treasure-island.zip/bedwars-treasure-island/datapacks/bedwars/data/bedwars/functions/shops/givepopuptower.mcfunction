give @s note_block{Unbreakable:1,display:{Name:'[{"text":"Pop-Up Tower","italic":false,"color":"green"}]'},HideFlags:103} 1
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

clear @s iron_ingot 24
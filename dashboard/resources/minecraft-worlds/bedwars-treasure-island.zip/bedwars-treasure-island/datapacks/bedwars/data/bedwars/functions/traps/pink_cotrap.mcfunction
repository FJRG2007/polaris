execute as @e[type=minecraft:armor_stand,tag=pink_trap] at @s run effect give @a[team=pink,distance=..15] jump_boost 15 2 true
execute as @e[type=minecraft:armor_stand,tag=pink_trap] at @s run effect give @a[team=pink,distance=..15] speed 15 8 true
scoreboard players set @e[type=minecraft:armor_stand,tag=pink_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/pink_reset 15s
scoreboard players set 30ddb309-0e8e-4b43-a453-b4925bda2343 trap1 0
scoreboard players set @a[team=pink] trap1 0
title @a[team=pink] subtitle {"text":"","color":"red"}
title @a[team=pink] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=pink] ~ ~ ~ 1 0.5
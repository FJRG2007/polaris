give @s minecraft:stick{display:{Name:'[{"text":"Knockback (II) Stick","italic":false}]'},Enchantments:[{id:knockback,lvl:2}],HideFlags:1} 1

clear @s gold_ingot 5
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

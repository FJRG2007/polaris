summon minecraft:armor_stand -86 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -46 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -6 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 6 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 46 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 86 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -126 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 126 75 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 75 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 75 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 75 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 75 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 75 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 75 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 75 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -86 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -46 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -6 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 6 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 46 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 86 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -126 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 126 93 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 93 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 93 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 93 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 93 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 93 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 93 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 93 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -86 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -86 57 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -46 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -46 57 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -6 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -6 57 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 6 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 6 57 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 46 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 46 57 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 86 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 86 57 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand -126 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand -126 57 126 {Tags:["reset"],NoGravity:1}

summon minecraft:armor_stand 126 57 126 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 57 -86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 57 -46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 57 -6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 57 6 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 57 46 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 57 86 {Tags:["reset"],NoGravity:1}
summon minecraft:armor_stand 126 57 126 {Tags:["reset"],NoGravity:1}

execute as @e[type=minecraft:armor_stand,tag=reset] at @s run fill ~20 ~9 ~20 ~-20 ~-9 ~-20 air replace #break
kill @e[type=armor_stand,tag=reset]

clone -112 66 -452 -100 81 -464 8 57 -77
clone -112 66 -452 -100 81 -464 -21 57 -77
clone -112 66 -452 -100 81 -464 -6 65 -56
clone -112 66 -452 -100 81 -464 65 57 -21
clone -112 66 -452 -100 81 -464 65 57 8
clone -112 66 -452 -100 81 -464 44 65 -6
clone -112 66 -452 -100 81 -464 9 57 65
clone -112 66 -452 -100 81 -464 -20 57 65
clone -112 66 -452 -100 81 -464 -6 65 44
clone -112 66 -452 -100 81 -464 -56 65 -6
clone -112 66 -452 -100 81 -464 -77 57 -21
clone -112 66 -452 -100 81 -464 -77 57 9
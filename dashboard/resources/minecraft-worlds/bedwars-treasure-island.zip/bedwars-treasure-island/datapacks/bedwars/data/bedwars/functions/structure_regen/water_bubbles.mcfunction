execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 8 57 -77 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 -21 57 -77 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 -6 65 -56 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 65 57 -21 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 65 57 8 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 44 65 -6 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 9 57 65 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 -20 57 65 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 -6 65 44 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 -56 65 -6 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 -77 57 -21 filtered minecraft:structure_void normal
execute if score ingame phase matches 1 run clone -112 66 -452 -100 81 -464 -77 57 9 filtered minecraft:structure_void normal
schedule function bedwars:structure_regen/water_bubbles 15t
execute as @a[tag=closed_red_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_red_shop] barrier

clear @a barrier

tag @a[tag=closed_red_shop] remove closed_red_shop
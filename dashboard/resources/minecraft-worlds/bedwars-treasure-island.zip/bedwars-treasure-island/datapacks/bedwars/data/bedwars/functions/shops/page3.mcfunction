item replace entity @s container.0 with minecraft:air
item replace entity @s container.1 with minecraft:air
item replace entity @s container.2 with minecraft:air
item replace entity @s container.3 with minecraft:air
item replace entity @s container.4 with minecraft:air
item replace entity @s container.5 with minecraft:air
item replace entity @s container.6 with minecraft:air
item replace entity @s container.7 with minecraft:air
item replace entity @s container.8 with minecraft:air
item replace entity @s container.9 with minecraft:air
item replace entity @s container.10 with minecraft:stone_sword{display:{Name:'[{"text":"Stone Sword","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 10 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:2} 1
item replace entity @s container.11 with minecraft:iron_sword{display:{Name:'[{"text":"Iron Sword","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"7 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:2} 1
item replace entity @s container.12 with minecraft:diamond_sword{display:{Name:'[{"text":"Diamond Sword","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:2} 1
item replace entity @s container.13 with minecraft:stick{display:{Name:'[{"text":"Knockback (II) Stick","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"5 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{id:knockback,lvl:2}],HideFlags:1} 1
item replace entity @s container.14 with minecraft:shield{Unbreakable:1,display:{Name:'[{"text":"Shield","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[],HideFlags:4} 1
item replace entity @s container.15 with minecraft:fishing_rod{Unbreakable:1,display:{Name:'[{"text":"Fishing Rod","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"5 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[],HideFlags:4} 1
item replace entity @s container.16 with skeleton_spawn_egg{display:{Name:'[{"text":"Portable Cannon","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"40 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Place it down to spawn a cannon","italic":false,"color":"dark_purple"}]','[{"text":"turret to defend you","italic":false,"color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"CLick to Purchase!","italic":false,"color":"yellow"}]']}} 1
item replace entity @s container.17 with minecraft:air
item replace entity @s container.19 with minecraft:air
item replace entity @s container.20 with minecraft:air
item replace entity @s container.21 with minecraft:air
item replace entity @s container.22 with minecraft:air
item replace entity @s container.23 with minecraft:air
item replace entity @s container.24 with minecraft:air
item replace entity @s container.25 with minecraft:air
give @s potion{CustomPotionColor:65293,display:{Name:'[{"text":"Jump Boost V Potion (45s)","italic":false,"color":"green"}]'},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:8,Duration:900,Amplifier:4,ShowParticles:0b}]}

clear @s emerald 1

playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

execute as @e[type=minecraft:armor_stand,tag=white_trap] at @s run effect give @a[team=white,distance=..15] jump_boost 15 2 true
execute as @e[type=minecraft:armor_stand,tag=white_trap] at @s run effect give @a[team=white,distance=..15] speed 15 8 true
scoreboard players set @e[type=minecraft:armor_stand,tag=white_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/white_reset 15s
scoreboard players set 5e09c1fa-8ba4-4fef-adfc-89aeec7815a3 trap1 0
scoreboard players set @a[team=white] trap1 0
title @a[team=white] subtitle {"text":"","color":"red"}
title @a[team=white] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=white] ~ ~ ~ 1 0.5
scoreboard players set @s wooden_pickaxe_count 1
clear @s iron_ingot 10
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @a[team=red] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=red_team_shop] sharpness 1


execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @a[team=blue] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=blue_team_shop] sharpness 1


execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @a[team=yellow] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] sharpness 1


execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @a[team=green] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=green_team_shop] sharpness 1


execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @a[team=gray] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=gray_team_shop] sharpness 1


execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @a[team=pink] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=pink_team_shop] sharpness 1


execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @a[team=white] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=white_team_shop] sharpness 1


execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @a[team=aqua] sharpness 1
execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] sharpness 1

clear @s diamond 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

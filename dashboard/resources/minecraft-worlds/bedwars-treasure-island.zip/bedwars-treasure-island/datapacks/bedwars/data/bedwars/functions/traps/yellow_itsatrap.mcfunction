execute as @e[type=minecraft:armor_stand,tag=yellow_trap] at @s run effect give @p[team=!yellow] blindness 8 1 true
execute as @e[type=minecraft:armor_stand,tag=yellow_trap] at @s run effect give @p[team=!yellow] slowness 8 1 true
scoreboard players set @e[type=minecraft:armor_stand,tag=yellow_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/yellow_reset 8s
scoreboard players set d2f56176-46c5-419d-84d2-b7d9f042da83 trap1 0
scoreboard players set @a[team=yellow] trap1 0
title @a[team=yellow] subtitle {"text":"","color":"red"}
title @a[team=yellow] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=yellow] ~ ~ ~ 1 0.5
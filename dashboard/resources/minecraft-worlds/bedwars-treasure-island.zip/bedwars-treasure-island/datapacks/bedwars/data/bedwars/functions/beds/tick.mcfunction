##Red Bed Detect
execute if score ingame phase matches 1 unless block -30 62 -80 red_bed if entity @a[scores={redBedBroken=1},team=!red] run scoreboard players set red beds 0

scoreboard players set @a[team=red] redBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block -30 62 -80 red_bed unless entity @a[scores={redBedBroken=1},team=!red] run setblock -30 62 -80 red_bed[part=foot]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score red beds matches 1 run setblock -30 62 -81 red_bed[part=head]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block -30 62 -80 red_bed run scoreboard players set red beds 1

execute if score ingame phase matches 1 if score red beds matches 0 if score red message matches 0 run function bedwars:beds/redmessage
##-------------------------------------------------------------------------------------------------------
##Blue Bed Detect
execute if score ingame phase matches 1 unless block 30 62 -80 blue_bed if entity @a[scores={blueBedBroken=1},team=!blue] run scoreboard players set blue beds 0

scoreboard players set @a[team=blue] blueBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block 30 62 -80 blue_bed unless entity @a[scores={blueBedBroken=1},team=!blue] run setblock 30 62 -80 blue_bed[part=foot]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score blue beds matches 1 run setblock 30 62 -81 blue_bed[part=head]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block 30 62 -80 blue_bed run scoreboard players set blue beds 1

execute if score ingame phase matches 1 if score blue beds matches 0 if score blue message matches 0 run function bedwars:beds/bluemessage
##-------------------------------------------------------------------------------------------------------
##Green Bed Detect
execute if score ingame phase matches 1 unless block 80 62 -30 green_bed if entity @a[scores={greenBedBroken=1},team=!green] run scoreboard players set green beds 0

scoreboard players set @a[team=green] greenBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block 80 62 -30 green_bed unless entity @a[scores={greenBedBroken=1},team=!green] run setblock 80 62 -30 lime_bed[part=foot,facing=east]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score green beds matches 1 run setblock 81 62 -30 lime_bed[part=head,facing=east]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block 80 62 -30 green_bed run scoreboard players set green beds 1

execute if score ingame phase matches 1 if score green beds matches 0 if score green message matches 0 run function bedwars:beds/greenmessage
##-------------------------------------------------------------------------------------------------------
##Yellow Bed Detect
execute if score ingame phase matches 1 unless block 80 62 30 yellow_bed if entity @a[scores={yellowBedBroken=1},team=!yellow] run scoreboard players set yellow beds 0

scoreboard players set @a[team=yellow] yellowBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block 80 62 30 yellow_bed unless entity @a[scores={yellowBedBroken=1},team=!yellow] run setblock 80 62 30 yellow_bed[part=foot,facing=east]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score yellow beds matches 1 run setblock 81 62 30 yellow_bed[part=head,facing=east]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block 80 62 30 yellow_bed run scoreboard players set yellow beds 1

execute if score ingame phase matches 1 if score yellow beds matches 0 if score yellow message matches 0 run function bedwars:beds/yellowmessage
##-------------------------------------------------------------------------------------------------------
##Cyan Bed Detect
execute if score ingame phase matches 1 unless block 30 62 80 cyan_bed if entity @a[scores={cyanBedBroken=1},team=!aqua] run scoreboard players set cyan beds 0

scoreboard players set @a[team=aqua] cyanBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block 30 62 80 cyan_bed unless entity @a[scores={cyanBedBroken=1},team=!aqua] run setblock 30 62 80 cyan_bed[part=foot,facing=south]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score cyan beds matches 1 run setblock 30 62 81 cyan_bed[part=head,facing=south]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block 30 62 80 cyan_bed run scoreboard players set cyan beds 1

execute if score ingame phase matches 1 if score cyan beds matches 0 if score aqua message matches 0 run function bedwars:beds/aquamessage
##-------------------------------------------------------------------------------------------------------
##White Bed Detect
execute if score ingame phase matches 1 unless block -30 62 80 white_bed if entity @a[scores={whiteBedBroken=1},team=!white] run scoreboard players set white beds 0

scoreboard players set @a[team=white] whiteBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block -30 62 80 white_bed unless entity @a[scores={whiteBedBroken=1},team=!white] run setblock -30 62 80 white_bed[part=foot,facing=south]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score white beds matches 1 run setblock -30 62 81 white_bed[part=head,facing=south]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block -30 62 80 white_bed run scoreboard players set white beds 1

execute if score ingame phase matches 1 if score white beds matches 0 if score white message matches 0 run function bedwars:beds/whitemessage
##-------------------------------------------------------------------------------------------------------
##Pink Bed Detect
execute if score ingame phase matches 1 unless block -80 62 30 pink_bed if entity @a[scores={pinkBedBroken=1},team=!pink] run scoreboard players set pink beds 0

scoreboard players set @a[team=pink] pinkBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block -80 62 30 pink_bed unless entity @a[scores={pinkBedBroken=1},team=!pink] run setblock -80 62 30 pink_bed[part=foot,facing=west]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score pink beds matches 1 run setblock -81 62 30 pink_bed[part=head,facing=west]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block -80 62 30 pink_bed run scoreboard players set pink beds 1

execute if score ingame phase matches 1 if score pink beds matches 0 if score pink message matches 0 run function bedwars:beds/pinkmessage
##-------------------------------------------------------------------------------------------------------
##Gray Bed Detect
execute if score ingame phase matches 1 unless block -80 62 -30 gray_bed if entity @a[scores={grayBedBroken=1},team=!gray] run scoreboard players set gray beds 0

scoreboard players set @a[team=gray] grayBedBroken 0

execute if score ingame phase matches 1 if score phase game_phase matches ..5 unless block -80 62 -30 gray_bed unless entity @a[scores={grayBedBroken=1},team=!gray] run setblock -80 62 -30 gray_bed[part=foot,facing=west]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if score gray beds matches 1 run setblock -81 62 -30 gray_bed[part=head,facing=west]

execute if score ingame phase matches 1 if score phase game_phase matches ..5 if block -80 62 -30 gray_bed run scoreboard players set gray beds 1

execute if score ingame phase matches 1 if score gray beds matches 0 if score gray message matches 0 run function bedwars:beds/graymessage
##-------------------------------------------------------------------------------------------------------
##Kill Bed Items
kill @e[type=item,nbt={Item:{id:"minecraft:red_bed"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:blue_bed"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:cyan_bed"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:pink_bed"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:gray_bed"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:white_bed"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:yellow_bed"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:lime_bed"}}]

execute if score phase game_phase matches 6.. run scoreboard players set red beds 0
execute if score phase game_phase matches 6.. run scoreboard players set blue beds 0
execute if score phase game_phase matches 6.. run scoreboard players set green beds 0
execute if score phase game_phase matches 6.. run scoreboard players set yellow beds 0
execute if score phase game_phase matches 6.. run scoreboard players set cyan beds 0
execute if score phase game_phase matches 6.. run scoreboard players set white beds 0
execute if score phase game_phase matches 6.. run scoreboard players set pink beds 0
execute if score phase game_phase matches 6.. run scoreboard players set gray beds 0
execute if score phase game_phase matches 6 run setblock -80 62 -30 air
execute if score phase game_phase matches 6 run setblock -81 62 -30 air
execute if score phase game_phase matches 6 run setblock -81 62 30 air
execute if score phase game_phase matches 6 run setblock -80 62 30 air
execute if score phase game_phase matches 6 run setblock -30 62 80 air
execute if score phase game_phase matches 6 run setblock -30 62 81 air
execute if score phase game_phase matches 6 run setblock 30 62 81 air
execute if score phase game_phase matches 6 run setblock 30 62 80 air
execute if score phase game_phase matches 6 run setblock 81 62 30 air
execute if score phase game_phase matches 6 run setblock 80 62 30 air
execute if score phase game_phase matches 6 run setblock 81 62 -30 air
execute if score phase game_phase matches 6 run setblock 80 62 -30 air
execute if score phase game_phase matches 6 run setblock 30 62 -81 air
execute if score phase game_phase matches 6 run setblock 30 62 -80 air
execute if score phase game_phase matches 6 run setblock -30 62 -81 air
execute if score phase game_phase matches 6 run setblock -30 62 -80 air
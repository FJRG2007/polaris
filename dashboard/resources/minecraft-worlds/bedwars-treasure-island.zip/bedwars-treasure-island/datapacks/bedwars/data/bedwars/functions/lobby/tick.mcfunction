##Aqua Team Items

execute if score aqua teamsfull matches 0 if score pregame phase matches 1 run team join aqua @a[nbt=!{Inventory:[{id:"minecraft:cyan_wool"}]}]

execute if score aqua teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:cyan_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=aqua] container.0 with cyan_wool{display:{Name:'[{"text":"Aqua Team (YOU)","italic":false,"color":"aqua"}]',Lore:['[{"text":"You are on the aqua team already!","italic":false,"color":"dark_aqua"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!aqua] container.0 with cyan_wool{display:{Name:'[{"text":"Aqua Team","italic":false,"color":"aqua"}]',Lore:['[{"text":"Drop this item to join the aqua team","italic":false,"color":"dark_aqua"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##White Team Items

execute if score white teamsfull matches 0 if score pregame phase matches 1 run team join white @a[nbt=!{Inventory:[{id:"minecraft:white_wool"}]}]

execute if score white teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:white_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=white] container.1 with white_wool{display:{Name:'[{"text":"White Team (YOU)","italic":false,"color":"white"}]',Lore:['[{"text":"You are on the white team already!","italic":false,"color":"gray"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!white] container.1 with white_wool{display:{Name:'[{"text":"White Team","italic":false,"color":"white"}]',Lore:['[{"text":"Drop this item to join the white team","italic":false,"color":"gray"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##Pink Team Items

execute if score pink teamsfull matches 0 if score pregame phase matches 1 run team join pink @a[nbt=!{Inventory:[{id:"minecraft:pink_wool"}]}]

execute if score pink teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:pink_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=pink] container.2 with pink_wool{display:{Name:'[{"text":"Pink Team (YOU)","italic":false,"color":"light_purple"}]',Lore:['[{"text":"You are on the pink team already!","italic":false,"color":"purple"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!pink] container.2 with pink_wool{display:{Name:'[{"text":"Pink Team","italic":false,"color":"light_purple"}]',Lore:['[{"text":"Drop this item to join the pink team","italic":false,"color":"purple"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##Gray Team Items

execute if score gray teamsfull matches 0 if score pregame phase matches 1 run team join gray @a[nbt=!{Inventory:[{id:"minecraft:gray_wool"}]}]

execute if score gray teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:gray_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=gray] container.3 with gray_wool{display:{Name:'[{"text":"Gray Team (YOU)","italic":false,"color":"gray"}]',Lore:['[{"text":"You are on the gray team already!","italic":false,"color":"dark_gray"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!gray] container.3 with gray_wool{display:{Name:'[{"text":"Gray Team","italic":false,"color":"gray"}]',Lore:['[{"text":"Drop this item to join the gray team","italic":false,"color":"dark_gray"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##Red Team Items

execute if score red teamsfull matches 0 if score pregame phase matches 1 run team join red @a[nbt=!{Inventory:[{id:"minecraft:red_wool"}]}]

execute if score red teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:red_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=red] container.4 with red_wool{display:{Name:'[{"text":"Red Team (YOU)","italic":false,"color":"red"}]',Lore:['[{"text":"You are on the red team already!","italic":false,"color":"dark_red"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!red] container.4 with red_wool{display:{Name:'[{"text":"Red Team","italic":false,"color":"red"}]',Lore:['[{"text":"Drop this item to join the red team","italic":false,"color":"dark_red"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##Blue Team Items

execute if score blue teamsfull matches 0 if score pregame phase matches 1 run team join blue @a[nbt=!{Inventory:[{id:"minecraft:blue_wool"}]}]

execute if score blue teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:blue_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=blue] container.5 with blue_wool{display:{Name:'[{"text":"Blue Team (YOU)","italic":false,"color":"blue"}]',Lore:['[{"text":"You are on the blue team already!","italic":false,"color":"dark_blue"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!blue] container.5 with blue_wool{display:{Name:'[{"text":"Blue Team","italic":false,"color":"blue"}]',Lore:['[{"text":"Drop this item to join the blue team","italic":false,"color":"dark_blue"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##Green Team Items

execute if score green teamsfull matches 0 if score pregame phase matches 1 run team join green @a[nbt=!{Inventory:[{id:"minecraft:lime_wool"}]}]

execute if score green teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:lime_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=green] container.6 with lime_wool{display:{Name:'[{"text":"Green Team (YOU)","italic":false,"color":"green"}]',Lore:['[{"text":"You are on the green team already!","italic":false,"color":"dark_green"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!green] container.6 with lime_wool{display:{Name:'[{"text":"Green Team","italic":false,"color":"green"}]',Lore:['[{"text":"Drop this item to join the green team","italic":false,"color":"dark_green"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##Yellow Team Items

execute if score yellow teamsfull matches 0 if score pregame phase matches 1 run team join yellow @a[nbt=!{Inventory:[{id:"minecraft:yellow_wool"}]}]

execute if score yellow teamsfull matches 1 if score pregame phase matches 1 run tellraw @a[nbt=!{Inventory:[{id:"minecraft:yellow_wool"}]}] {"text":"That team is already full!","color":"red"}

execute if score pregame phase matches 1 run item replace entity @a[team=yellow] container.7 with yellow_wool{display:{Name:'[{"text":"Yellow Team (YOU)","italic":false,"color":"yellow"}]',Lore:['[{"text":"You are on the yellow team already!","italic":false,"color":"gold"}]']},Enchantments:[{}]} 1

execute if score pregame phase matches 1 run item replace entity @a[team=!yellow] container.7 with yellow_wool{display:{Name:'[{"text":"Yellow Team","italic":false,"color":"yellow"}]',Lore:['[{"text":"Drop this item to join the yellow team","italic":false,"color":"gold"}]']}} 1
##--------------------------------------------------------------------------------------------------------------
##Clear Items

execute if score pregame phase matches 1 run kill @e[type=item]
##--------------------------------------------------------------------------------------------------------------
##Detect Team Limits

scoreboard players set aqua teamplayerscount 0
execute as @a[team=aqua,tag=!Eliminated] run scoreboard players add aqua teamplayerscount 1
execute if score aqua teamplayerscount matches 2 run scoreboard players set aqua teamsfull 1
execute if score aqua teamplayerscount matches ..1 run scoreboard players set aqua teamsfull 0

scoreboard players set white teamplayerscount 0
execute as @a[team=white,tag=!Eliminated] run scoreboard players add white teamplayerscount 1
execute if score white teamplayerscount matches 2 run scoreboard players set white teamsfull 1
execute if score white teamplayerscount matches ..1 run scoreboard players set white teamsfull 0

scoreboard players set pink teamplayerscount 0
execute as @a[team=pink,tag=!Eliminated] run scoreboard players add pink teamplayerscount 1
execute if score pink teamplayerscount matches 2 run scoreboard players set pink teamsfull 1
execute if score pink teamplayerscount matches ..1 run scoreboard players set pink teamsfull 0

scoreboard players set gray teamplayerscount 0
execute as @a[team=gray,tag=!Eliminated] run scoreboard players add gray teamplayerscount 1
execute if score gray teamplayerscount matches 2 run scoreboard players set gray teamsfull 1
execute if score gray teamplayerscount matches ..1 run scoreboard players set gray teamsfull 0

scoreboard players set red teamplayerscount 0
execute as @a[team=red,tag=!Eliminated] run scoreboard players add red teamplayerscount 1
execute if score red teamplayerscount matches 2 run scoreboard players set red teamsfull 1
execute if score red teamplayerscount matches ..1 run scoreboard players set red teamsfull 0

scoreboard players set blue teamplayerscount 0
execute as @a[team=blue,tag=!Eliminated] run scoreboard players add blue teamplayerscount 1
execute if score blue teamplayerscount matches 2 run scoreboard players set blue teamsfull 1
execute if score blue teamplayerscount matches ..1 run scoreboard players set blue teamsfull 0

scoreboard players set green teamplayerscount 0
execute as @a[team=green,tag=!Eliminated] run scoreboard players add green teamplayerscount 1
execute if score green teamplayerscount matches 2 run scoreboard players set green teamsfull 1
execute if score green teamplayerscount matches ..1 run scoreboard players set green teamsfull 0

scoreboard players set yellow teamplayerscount 0
execute as @a[team=yellow,tag=!Eliminated] run scoreboard players add yellow teamplayerscount 1
execute if score yellow teamplayerscount matches 2 run scoreboard players set yellow teamsfull 1
execute if score yellow teamplayerscount matches ..1 run scoreboard players set yellow teamsfull 0
##--------------------------------------------------------------------------------------------------------------
##Lobby SpawnPoint

execute if score pregame phase matches 1 run spawnpoint @a 0 123 0 -90
##--------------------------------------------------------------------------------------------------------------
#Team Spawnpoints

execute if score ingame phase matches 1 run spawnpoint @a 0 105 0 0
##---------------------------------------------------------------------------------------------------------------
##CreateTeams

function bedwars:events/createteams


execute as @e[x=-157,y=-64,z=-178,dx=290,dy=-4,dz=318] at @s run kill @s


execute if score pregame phase matches 1 run gamemode adventure @a[tag=!devmode]
execute if score ingame phase matches 1 if score gameover gameover matches 0 run gamemode survival @a[tag=!devmode,tag=!dead6,tag=!dead5,tag=!dead4,tag=!dead3,tag=!dead2,tag=!dead1]
execute if score pregame phase matches 1 run tag @a remove launched
execute if score pregame phase matches 1 run tag @a remove player


##effects

effect give @a saturation infinite 255 true
gamerule commandBlockOutput false
##gamerule sendCommandFeedback false
gamerule announceAdvancements false
gamerule doDaylightCycle false
gamerule doEntityDrops false
gamerule doFireTick false
gamerule doImmediateRespawn true
gamerule doMobLoot false
gamerule doMobSpawning false
gamerule doPatrolSpawning false
gamerule doTileDrops true
gamerule doTraderSpawning false
gamerule doWeatherCycle false
gamerule drowningDamage true
gamerule fallDamage true
gamerule keepInventory false
gamerule mobGriefing true
gamerule naturalRegeneration false

execute unless block 91 62 -27 minecraft:trapped_chest run setblock 91 62 -27 minecraft:trapped_chest[facing=east]
execute unless block 91 62 33 minecraft:trapped_chest run setblock 91 62 33 minecraft:trapped_chest[facing=east]
execute unless block 27 62 91 minecraft:trapped_chest run setblock 27 62 91 minecraft:trapped_chest[facing=south]
execute unless block -33 62 91 minecraft:trapped_chest run setblock -33 62 91 minecraft:trapped_chest[facing=south]
execute unless block -91 62 27 minecraft:trapped_chest run setblock -91 62 27 minecraft:trapped_chest[facing=west]
execute unless block -91 62 -33 minecraft:trapped_chest run setblock -91 62 -33 minecraft:trapped_chest[facing=west]
execute unless block -27 62 -91 minecraft:trapped_chest run setblock -27 62 -91 minecraft:trapped_chest[facing=north]
execute unless block 33 62 -91 minecraft:trapped_chest run setblock 33 62 -91 minecraft:trapped_chest[facing=north]

execute unless block 34 62 91 minecraft:ender_chest run setblock 34 62 91 minecraft:ender_chest[facing=south]
execute unless block -26 62 91 minecraft:ender_chest run setblock -26 62 91 minecraft:ender_chest[facing=south]
execute unless block -91 62 34 minecraft:ender_chest run setblock -91 62 34 minecraft:ender_chest[facing=west]
execute unless block -91 62 -26 minecraft:ender_chest run setblock -91 62 -26 minecraft:ender_chest[facing=west]
execute unless block 26 62 -91 minecraft:ender_chest run setblock 26 62 -91 minecraft:ender_chest[facing=north]
execute unless block -34 62 -91 minecraft:ender_chest run setblock -34 62 -91 minecraft:ender_chest[facing=north]
execute unless block 91 62 26 minecraft:ender_chest run setblock 91 62 26 minecraft:ender_chest[facing=east]
execute unless block 91 62 -34 minecraft:ender_chest run setblock 91 62 -34 minecraft:ender_chest[facing=east]

team modify aqua color aqua
team modify blue color blue
team modify gray color dark_gray
team modify green color green
team modify pink color light_purple
team modify red color red
team modify white color white
team modify yellow color yellow
team modify aqua collisionRule pushOtherTeams
team modify blue collisionRule pushOtherTeams
team modify gray collisionRule pushOtherTeams
team modify green collisionRule pushOtherTeams
team modify pink collisionRule pushOtherTeams
team modify red collisionRule pushOtherTeams
team modify white collisionRule pushOtherTeams
team modify yellow collisionRule pushOtherTeams
team modify aqua friendlyFire false
team modify gray friendlyFire false
team modify white friendlyFire false
team modify pink friendlyFire false
team modify red friendlyFire false
team modify blue friendlyFire false
team modify yellow friendlyFire false
team modify green friendlyFire false


execute if score pregame phase matches 1 run effect give @a minecraft:weakness 1 255 true

kill @e[type=item,nbt={Item:{id:"minecraft:cobbled_deepslate"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:deepslate"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:deepslate_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:deepslate_stairs"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:cobbled_deepslate_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:cobbled_deepslate_stairs"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:polished_deepslate_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:smooth_basalt"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:sand"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:smooth_sandstone"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:barrel"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:trapped_chest"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:ender_chest"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:cyan_stained_glass"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:jungle_fence"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:player_head"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_leaves"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:oak_leaves"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:chain"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:lantern"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:skeleton_skull"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stone"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:cobblestone"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:white_carpet"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:spruce_fence"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:jungle_wood"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:red_carpet"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:campfire"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:string"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:charcoal"}}]
clear @a crafting_table
kill @e[type=item,nbt={Item:{id:"minecraft:glass"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:smooth_stone"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:spruce_planks"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:spruce_stairs"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:spruce_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:spruce_log"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:tuff"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:andesite"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stripped_mangrove_wood"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_block"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_planks"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_stairs"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_trapdoor"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:magma_block"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:polished_andesite"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:dead_brain_coral"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stripped_spruce_log"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_log"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:spruce_trapdoor"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:grass_block"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:rooted_dirt"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:coarse_dirt"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:dirt"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:podzol"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:acacia_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:orange_banner"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:pointed_dripstone"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:white_banner"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:bone_block"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stripped_jungle_wood"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stone_brick_stairs"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:chiseled_stone_bricks"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:deepslate_brick_stairs"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:oak_fence"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:dirt_path"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:jungle_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:oak_slab"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:acacia_fence"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:ladder"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stripped_acacia_wood"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:polished_deepslate"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:lily_pad"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:dripstone_block"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:red_banner"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:green_banner"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:cyan_banner"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:redstone_torch"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:tinted_glass"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:cobbled_deepslate_wall"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stripped_spruce_wood"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:moss_block"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:hay_block"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:iron_leggings"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:chainmail_leggings"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_leggings"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:iron_boots"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:chainmail_boots"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_boots"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:leather_helmet"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:leather_chestplate"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:wooden_axe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:stone_axe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:iron_axe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_axe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:wooden_pickaxe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:golden_pickaxe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:iron_pickaxe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:diamond_pickaxe"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:shears"}}]
kill @e[type=item,nbt={Item:{id:"minecraft:mangrove_sign"}}]

clear @a glass_bottle

setblock -3 93 1 ladder[facing=north]
##--------------------------------------------------------------------------------------------------------------
##Start Game

execute store result score playercount playercount if entity @e[type=player]


fill 74 64 85 74 64 87 minecraft:structure_void
fill 74 63 88 74 62 84 minecraft:structure_void
fill 85 64 74 87 64 74 minecraft:structure_void
fill 88 63 74 84 62 74 minecraft:structure_void

fill -74 64 85 -74 64 87 minecraft:structure_void
fill -74 63 88 -74 62 84 minecraft:structure_void
fill -85 64 74 -87 64 74 minecraft:structure_void
fill -88 63 74 -84 62 74 minecraft:structure_void

fill 74 64 -85 74 64 -87 minecraft:structure_void
fill 74 63 -88 74 62 -84 minecraft:structure_void
fill 85 64 -74 87 64 -74 minecraft:structure_void
fill 88 63 -74 84 62 -74 minecraft:structure_void

fill -74 64 -85 -74 64 -87 minecraft:structure_void
fill -74 63 -88 -74 62 -84 minecraft:structure_void
fill -85 64 -74 -87 64 -74 minecraft:structure_void
fill -88 63 -74 -84 62 -74 minecraft:structure_void

setblock -2 94 2 minecraft:stripped_spruce_wood
setblock -3 94 2 ladder[facing=west]
setblock -3 93 2 ladder[facing=west]
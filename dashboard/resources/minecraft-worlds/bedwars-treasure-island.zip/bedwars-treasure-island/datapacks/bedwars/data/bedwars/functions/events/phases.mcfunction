##1) Diamond I --> Diamond II  -  6 minutes (360s)
##2) Diamond II --> Emerald II  -  6 minutes (360s)
##3) Emerald II --> Diamond III  -  6 minutes (360s)
##4) Diamond III --> Emerald III  -  6 minutes (360s)
##5) Emerald III --> Beds Gone  -  10 minutes (600s)
##6) Beds Gone --> Sudden Death  -  10 minutes (600s)




execute if score time game_phase matches 1.. run schedule function bedwars:events/timer 1s
execute if score time game_phase matches 0 if score phase game_phase matches ..6 run schedule function bedwars:events/nextphase 1s

execute if score time game_phase matches 300 if score phase game_phase matches 1 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 240 if score phase game_phase matches 1 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 180 if score phase game_phase matches 1 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 120 if score phase game_phase matches 1 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 60 if score phase game_phase matches 1 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 1 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}

execute if score time game_phase matches 300 if score phase game_phase matches 2 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 240 if score phase game_phase matches 2 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 180 if score phase game_phase matches 2 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 120 if score phase game_phase matches 2 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 60 if score phase game_phase matches 2 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 2 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}

execute if score time game_phase matches 315 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 270 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 225 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 180 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 135 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 90 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 45 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 3 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}

execute if score time game_phase matches 315 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 270 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 225 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 180 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 135 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 90 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 45 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 4 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}

execute if score time game_phase matches 330 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 300 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 270 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 240 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 210 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 180 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 150 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 120 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 90 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 60 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 30 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 5..7 as @e[type=armor_stand,tag=emgen] at @s run summon item ~ ~ ~ {Item: {id: "emerald",Count: 1}}



execute if score time game_phase matches 330 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 300 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 270 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 240 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 210 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 180 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 150 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 120 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 90 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 60 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 30 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 1 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}

execute if score time game_phase matches 336 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 312 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 288 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 264 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 240 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 216 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 192 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 168 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 144 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 120 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 96 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 72 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 48 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 24 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 2..3 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}

execute if score time game_phase matches 345 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 330 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 315 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 300 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 285 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 270 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 255 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 240 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 225 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 210 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 195 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 180 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 165 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 150 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 135 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 120 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 105 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 90 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 75 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 60 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 45 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 30 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 15 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}
execute if score time game_phase matches 0 if score phase game_phase matches 4..7 as @e[type=armor_stand,tag=diagen] at @s run summon item ~ ~ ~ {Item: {id: "diamond",Count: 1}}


execute if score border shrinking matches 0 if score phase game_phase matches 7 run worldborder set 8 180
execute if score border shrinking matches 0 if score phase game_phase matches 7 run scoreboard players set border shrinking 0
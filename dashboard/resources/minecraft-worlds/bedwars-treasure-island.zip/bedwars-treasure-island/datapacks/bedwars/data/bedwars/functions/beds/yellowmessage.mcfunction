scoreboard players set yellow message 1
playsound minecraft:entity.ender_dragon.growl master @a 0 100 0 1 1 1
tellraw @a ["",{"text":"BED DESTRUCTION >","bold":true,"color":"white"},{"text":" Yellow Bed","color":"yellow"},{"text":" was destroyed by ","color":"gray"},{"selector":"@a[scores={redBedBroken=1}]","color":"dark_red"}]
title @a subtitle {"text":"You will no longer respawn!","color":"white"}
title @a[team=yellow] title {"text":"Bed Destroyed","color":"red"}

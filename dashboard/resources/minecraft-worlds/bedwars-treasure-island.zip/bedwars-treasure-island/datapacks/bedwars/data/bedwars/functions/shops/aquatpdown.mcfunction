execute as @a[tag=closed_aqua_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_aqua_shop] barrier

clear @a barrier

tag @a[tag=closed_aqua_shop] remove closed_aqua_shop
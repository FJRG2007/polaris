execute as @e[type=egg] at @s run summon minecraft:firework_rocket ~ ~ ~ {LifeTime:0b}
execute as @e[type=firework_rocket] at @s run tag @p add launching
kill @e[type=egg]
execute as @e[type=firework_rocket] at @s run effect give @p minecraft:levitation 1 120 true
execute as @a[tag=launching] at @s run tag @s add launched
item replace entity @a[tag=launched] armor.feet with netherite_boots{display:{Name:'[{"text":"Booster Boots","italic":false}]'},Enchantments:[{id:feather_falling,lvl:1000}]}
execute as @a[tag=launching] at @s run schedule function bedwars:items/booster_remove 3t
execute as @a at @s run function bedwars:items/boots_detect
clear @a[nbt={Inventory:[{id:"minecraft:netherite_boots",Slot:100b}]},tag=!launched] netherite_boots
kill @e[type=firework_rocket]
tag @a remove launching

function bedwars:items/invis
gamemode spectator @s
tag @a[tag=dead2] add dead1
tag @a[tag=dead2] remove dead2

title @a[tag=dead1] title {"text":"You Died!","color":"red"}
title @a[tag=dead1] subtitle {"text":"Respawning in 1","color":"red"}

schedule function bedwars:death/death1 1s
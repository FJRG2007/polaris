execute as @e[type=minecraft:armor_stand,tag=aqua_trap] at @s run effect clear @a[team=!aqua,distance=..7] invisibility
scoreboard players set @e[type=minecraft:armor_stand,tag=aqua_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/aqua_reset 10s
scoreboard players set cbfc8205-35e3-4395-b149-145955e8e366 trap1 0
scoreboard players set @a[team=aqua] trap1 0

title @a[team=aqua] subtitle {"text":"","color":"red"}
title @a[team=aqua] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=aqua] ~ ~ ~ 1 0.5
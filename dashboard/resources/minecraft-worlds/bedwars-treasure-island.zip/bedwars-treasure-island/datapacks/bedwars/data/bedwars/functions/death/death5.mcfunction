gamemode spectator @s
tag @a[tag=dead5] add dead4
tag @a[tag=dead5] remove dead5

title @a[tag=dead4] title {"text":"You Died!","color":"red"}
title @a[tag=dead4] subtitle {"text":"Respawning in 4","color":"red"}

schedule function bedwars:death/death4 1s
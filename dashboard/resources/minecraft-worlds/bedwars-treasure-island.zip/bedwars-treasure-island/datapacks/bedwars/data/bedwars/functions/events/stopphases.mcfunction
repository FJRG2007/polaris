scoreboard players set time game_phase -1
scoreboard players set phase game_phase 0
scoreboard players set gameover gameover 1

execute if score ingame phase matches 1 if score red eliminated matches 0 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=red] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 0 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=!red] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 0 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run tellraw @a {"text":"Red Team has won!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 0 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=blue] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 0 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=!blue] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 0 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run tellraw @a {"text":"Blue Team has won!","color":"blue"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 0 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=green] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 0 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=!green] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 0 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run tellraw @a {"text":"Green Team has won!","color":"green"}


execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 0 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=yellow] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 0 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=!yellow] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 0 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run tellraw @a {"text":"Yellow Team has won!","color":"yellow"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 0 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=aqua] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 0 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=!aqua] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 0 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run tellraw @a {"text":"Aqua Team has won!","color":"aqua"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 0 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=white] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 0 if score gray eliminated matches 1 if score pink eliminated matches 1 run title @a[team=!white] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 0 if score gray eliminated matches 1 if score pink eliminated matches 1 run tellraw @a {"text":"White Team has won!","color":"white"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 0 if score pink eliminated matches 1 run title @a[team=gray] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 0 if score pink eliminated matches 1 run title @a[team=!gray] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 0 if score pink eliminated matches 1 run tellraw @a {"text":"Gray Team has won!","color":"gray"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 0 run title @a[team=pink] title {"text":"VICTORY!","color":"gold"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 0 run title @a[team=!pink] title {"text":"Game Over!","color":"red"}

execute if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 0 run tellraw @a {"text":"Pink Team has won!","color":"light_purple"}

gamemode spectator @a

schedule function bedwars:events/end_game 4s

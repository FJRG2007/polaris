team join noteam @a
schedule function bedwars:events/createteams 1t
give @s fishing_rod{Unbreakable:1,display:{Name:'[{"text":"Fishing Rod","italic":false}]'},HideFlags:6,Null:0b} 1

clear @s gold_ingot 5
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

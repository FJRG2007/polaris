execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @a[team=red] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=red_team_shop] protection 4

execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @a[team=blue] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=blue_team_shop] protection 4

execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @a[team=green] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=green_team_shop] protection 4

execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @a[team=yellow] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] protection 4

execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @a[team=gray] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=gray_team_shop] protection 4

execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @a[team=pink] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=pink_team_shop] protection 4

execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @a[team=white] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=white_team_shop] protection 4

execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @a[team=aqua] protection 4
execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] protection 4

clear @s diamond 16
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

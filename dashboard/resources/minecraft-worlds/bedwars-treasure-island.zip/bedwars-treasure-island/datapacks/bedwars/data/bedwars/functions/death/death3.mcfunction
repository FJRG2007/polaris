gamemode spectator @s
tag @a[tag=dead3] add dead2
tag @a[tag=dead3] remove dead3

title @a[tag=dead2] title {"text":"You Died!","color":"red"}
title @a[tag=dead2] subtitle {"text":"Respawning in 2","color":"red"}

schedule function bedwars:death/death2 1s
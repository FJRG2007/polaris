execute as @a[tag=closed_white_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_white_shop] barrier

clear @a barrier

tag @a[tag=closed_white_shop] remove closed_white_shop
scoreboard players remove time game_phase 1
function bedwars:events/phases
scoreboard players set @a chainmail_armor 0
scoreboard players set @a iron_armor 0
scoreboard players set @a diamond_armor 0
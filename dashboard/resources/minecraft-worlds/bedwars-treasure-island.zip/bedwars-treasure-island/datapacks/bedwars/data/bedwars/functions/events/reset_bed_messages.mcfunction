scoreboard players set red message 0
scoreboard players set blue message 0
scoreboard players set green message 0
scoreboard players set yellow message 0
scoreboard players set gray message 0
scoreboard players set pink message 0
scoreboard players set white message 0
scoreboard players set aqua message 0
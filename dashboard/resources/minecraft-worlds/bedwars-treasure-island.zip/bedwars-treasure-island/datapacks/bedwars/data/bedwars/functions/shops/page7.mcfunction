item replace entity @s container.0 with minecraft:air
item replace entity @s container.1 with minecraft:air
item replace entity @s container.2 with minecraft:air
item replace entity @s container.3 with minecraft:air
item replace entity @s container.4 with minecraft:air
item replace entity @s container.5 with minecraft:air
item replace entity @s container.6 with minecraft:air
item replace entity @s container.7 with minecraft:air
item replace entity @s container.8 with minecraft:air
item replace entity @s container.9 with minecraft:air
item replace entity @s container.10 with minecraft:air
item replace entity @s container.11 with minecraft:air
item replace entity @s container.12 with potion{CustomPotionColor:10322096,display:{Name:'[{"text":"Invisibility Potion (30s)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 2 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:14,Duration:600,Amplifier:1,ShowParticles:0b}]} 1
item replace entity @s container.13 with potion{CustomPotionColor:4617661,display:{Name:'[{"text":"Speed II Potion (45s)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 1 Emerald","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:1,Duration:900,Amplifier:1,ShowParticles:0b}]} 1
item replace entity @s container.14 with potion{CustomPotionColor:65293,display:{Name:'[{"text":"Jump Boost V Potion (45s)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 1 Emerald","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:8,Duration:900,Amplifier:4,ShowParticles:0b}]} 1
item replace entity @s container.15 with minecraft:air
item replace entity @s container.16 with minecraft:air
item replace entity @s container.17 with minecraft:air
item replace entity @s container.19 with minecraft:air
item replace entity @s container.20 with minecraft:air
item replace entity @s container.21 with minecraft:air
item replace entity @s container.22 with minecraft:air
item replace entity @s container.23 with minecraft:air
item replace entity @s container.24 with minecraft:air
item replace entity @s container.25 with minecraft:air
scoreboard players set @s stone_axe_count 0
clear @s stone_axe
scoreboard players set @s iron_axe_count 1
clear @s gold_ingot 8
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

execute as @e[type=minecraft:armor_stand,tag=red_trap] at @s run effect clear @a[team=!red,distance=..7] invisibility
scoreboard players set @e[type=minecraft:armor_stand,tag=red_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/red_reset 10s
scoreboard players set dbc7cab8-fad6-4e03-a806-df0fbc407fa8 trap1 0
scoreboard players set @a[team=red] trap1 0

title @a[team=red] subtitle {"text":"","color":"red"}
title @a[team=red] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=red] ~ ~ ~ 1 0.5
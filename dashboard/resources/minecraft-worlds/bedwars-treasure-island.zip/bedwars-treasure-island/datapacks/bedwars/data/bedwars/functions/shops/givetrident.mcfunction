give @s trident{Unbreakable:1,display:{Name:'[{"text":"Trident","italic":false,"color":"green"}]'},HideFlags:102} 1

clear @s gold_ingot 3
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

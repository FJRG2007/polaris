execute if entity @s[team=blue] run give @s blue_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24
execute if entity @s[team=red] run give @s red_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24
execute if entity @s[team=green] run give @s lime_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24
execute if entity @s[team=yellow] run give @s yellow_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24
execute if entity @s[team=pink] run give @s pink_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24
execute if entity @s[team=aqua] run give @s cyan_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24
execute if entity @s[team=gray] run give @s gray_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24
execute if entity @s[team=white] run give @s white_concrete{Unbreakable:1,display:{Name:'[{"text":"Concrete","italic":false}]'},HideFlags:6,Null:0b} 24

clear @s iron_ingot 16
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

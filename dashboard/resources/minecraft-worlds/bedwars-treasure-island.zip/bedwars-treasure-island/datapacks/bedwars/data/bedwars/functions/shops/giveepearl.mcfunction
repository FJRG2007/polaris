give @s ender_pearl{Unbreakable:1,display:{Name:'[{"text":"Ender Pearl","italic":false,"color":"green"}]'},HideFlags:103} 1

clear @s emerald 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

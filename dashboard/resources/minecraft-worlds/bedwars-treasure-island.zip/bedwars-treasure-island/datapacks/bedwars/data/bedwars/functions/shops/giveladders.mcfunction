give @s ladder{Unbreakable:1,display:{Name:'[{"text":"Ladder","italic":false}]'},HideFlags:6,Null:0b} 8

clear @s iron_ingot 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

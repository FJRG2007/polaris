execute as @e[type=minecraft:armor_stand,tag=yellow_team_gen] at @s run summon item ~ ~1 ~ {Item:{id:"iron_ingot",Count:1}}

execute as @e[type=armor_stand,tag=yellow_team_gen] at @s if score @s gold matches 1.. run scoreboard players remove @s gold 1

execute as @e[type=armor_stand,tag=yellow_team_gen] at @s if score @s em matches 1.. if score @s forge matches 3.. run scoreboard players remove @s em 1

execute as @e[type=minecraft:armor_stand,tag=yellow_team_gen] at @s if score @s em matches 0 if score @s forge matches 3.. run summon item ~ ~1 ~ {Item:{id:"emerald",Count:1}}

execute as @e[type=minecraft:armor_stand,tag=yellow_team_gen] at @s if score @s gold matches 0 run summon item ~ ~1 ~ {Item:{id:"gold_ingot",Count:1}}

execute as @e[type=armor_stand,tag=yellow_team_gen] at @s if score @s gold matches 0 run scoreboard players set @s gold 4

execute as @e[type=armor_stand,tag=yellow_team_gen] at @s if score @s em matches 0 run scoreboard players set @s em 60


function bedwars:events/gen_yellowmanage
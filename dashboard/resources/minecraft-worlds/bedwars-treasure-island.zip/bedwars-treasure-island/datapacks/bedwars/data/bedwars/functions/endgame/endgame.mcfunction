execute if score ingame phase matches 1 if score red teamplayerscount matches 0 run scoreboard players set red eliminated 1
execute if score ingame phase matches 1 if score blue teamplayerscount matches 0 run scoreboard players set blue eliminated 1
execute if score ingame phase matches 1 if score green teamplayerscount matches 0 run scoreboard players set green eliminated 1
execute if score ingame phase matches 1 if score yellow teamplayerscount matches 0 run scoreboard players set yellow eliminated 1
execute if score ingame phase matches 1 if score gray teamplayerscount matches 0 run scoreboard players set gray eliminated 1
execute if score ingame phase matches 1 if score pink teamplayerscount matches 0 run scoreboard players set pink eliminated 1
execute if score ingame phase matches 1 if score white teamplayerscount matches 0 run scoreboard players set white eliminated 1
execute if score ingame phase matches 1 if score aqua teamplayerscount matches 0 run scoreboard players set aqua eliminated 1


execute if score ingame phase matches 1 if score phase game_phase matches 7 if score time game_phase matches 0 if score gameover gameover matches 0 run function bedwars:endgame/stalemate

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 0 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run function bedwars:endgame/game_over

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 0 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run function bedwars:endgame/game_over

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 0 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run function bedwars:endgame/game_over

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 0 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run function bedwars:endgame/game_over

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 0 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 1 run function bedwars:endgame/game_over

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 0 if score gray eliminated matches 1 if score pink eliminated matches 1 run function bedwars:endgame/game_over

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 0 if score pink eliminated matches 1 run function bedwars:endgame/game_over

execute if score gameover gameover matches 0 if score ingame phase matches 1 if score red eliminated matches 1 if score blue eliminated matches 1 if score green eliminated matches 1 if score yellow eliminated matches 1 if score aqua eliminated matches 1 if score white eliminated matches 1 if score gray eliminated matches 1 if score pink eliminated matches 0 run function bedwars:endgame/game_over

execute as @a at @s if score @s HP matches ..0 run tag @s add dead6
execute as @a[tag=dead6] at @s run function bedwars:death/death6

spawnpoint @a 0 105 0 0
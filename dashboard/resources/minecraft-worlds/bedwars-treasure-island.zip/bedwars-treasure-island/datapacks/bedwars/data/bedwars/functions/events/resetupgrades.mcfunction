scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] sharpness 0
scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] protection 0
scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] haste 0
scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] heal_pool 0
scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] forge 0
scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] trap1 0
scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] trap2 0
scoreboard players set @e[type=minecraft:chest_minecart,tag=team_shop] trap3 0

scoreboard players set @a sharpness 0
scoreboard players set @a protection 0
scoreboard players set @a haste 0
scoreboard players set @a heal_pool 0
scoreboard players set @a forge 0
scoreboard players set @a trap1 0
scoreboard players set @a trap2 0
scoreboard players set @a trap3 0
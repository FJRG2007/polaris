execute if score phase game_phase matches 6 run scoreboard players set phase game_phase 7
execute if score phase game_phase matches 5 run scoreboard players set phase game_phase 6
execute if score phase game_phase matches 4 run scoreboard players set phase game_phase 5
execute if score phase game_phase matches 3 run scoreboard players set phase game_phase 4
execute if score phase game_phase matches 2 run scoreboard players set phase game_phase 3
execute if score phase game_phase matches 1 run scoreboard players set phase game_phase 2

scoreboard players set time game_phase 360
##should be 360

schedule function bedwars:events/phases 1t



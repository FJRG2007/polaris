give @s iron_golem_spawn_egg{Unbreakable:1,display:{Name:'[{"text":"Iron Golem Egg","italic":false,"color":"green"}]'},HideFlags:103} 1

clear @s iron_ingot 150
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

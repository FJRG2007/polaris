execute if score ingame phase matches 1 run tellraw @a[scores={leftmidgame=1}] {"text":"A game is already in progress, you are spectating.","color":"red"}
execute if score ingame phase matches 1 run tag @a[tag=!player] add spectator
execute if score ingame phase matches 1 run gamemode spectator @a[tag=spectator,tag=!devmode]
execute if score ingame phase matches 1 run tag @a[scores={leftmidgame=1..}] add spectator
execute if score pregame phase matches 1 run tag @a remove spectator
execute if score pregame phase matches 1 run tp @a[scores={leftmidgame=1..}] 0 123 0
execute if score pregame phase matches 1 run team leave @a[scores={leftmidgame=1..}]
scoreboard players set @a leftmidgame 0

execute if score ingame phase matches 1 run effect give @a[tag=!dead6,tag=!dead5,tag=!dead4,tag=!dead3,tag=!dead2,tag=!dead1,x=-125,y=119,z=-125,dx=250,dy=8,dz=250] minecraft:wither 1 5 true
execute if score pregame phase matches 1 run effect give @a minecraft:regeneration 1 255 true
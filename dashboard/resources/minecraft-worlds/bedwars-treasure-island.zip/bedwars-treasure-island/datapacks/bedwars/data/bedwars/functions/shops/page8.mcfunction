item replace entity @s container.0 with minecraft:air
item replace entity @s container.1 with minecraft:air
item replace entity @s container.2 with minecraft:air
item replace entity @s container.3 with minecraft:air
item replace entity @s container.4 with minecraft:air
item replace entity @s container.5 with minecraft:air
item replace entity @s container.6 with minecraft:air
item replace entity @s container.7 with minecraft:air
item replace entity @s container.8 with minecraft:air
item replace entity @s container.9 with minecraft:air
item replace entity @s container.10 with note_block{Unbreakable:1,display:{Name:'[{"text":"Pop-Up Tower","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 24 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
item replace entity @s container.11 with tnt{Unbreakable:1,display:{Name:'[{"text":"TNT","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
item replace entity @s container.12 with fire_charge{Unbreakable:1,display:{Name:'[{"text":"Fireball","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 40 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
item replace entity @s container.13 with golden_apple{Unbreakable:1,display:{Name:'[{"text":"Golden Apple","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"3 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
item replace entity @s container.14 with ender_pearl{Unbreakable:1,display:{Name:'[{"text":"Ender Pearl","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
item replace entity @s container.15 with iron_golem_spawn_egg{Unbreakable:1,display:{Name:'[{"text":"Iron Golem Egg","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_green"},{"text":"150 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"This feature has not been implemented yet!","italic":false,"color":"red"}]']},HideFlags:103} 1
item replace entity @s container.16 with egg{display:{Name:'[{"text":"Cloud Jumper","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"6 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"Right-Click to launch into the sky","italic":false,"color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 1
item replace entity @s container.17 with minecraft:air
item replace entity @s container.19 with minecraft:air
item replace entity @s container.20 with minecraft:air
item replace entity @s container.21 with minecraft:air
item replace entity @s container.22 with minecraft:air
item replace entity @s container.23 with minecraft:air
item replace entity @s container.24 with minecraft:air
item replace entity @s container.25 with minecraft:air
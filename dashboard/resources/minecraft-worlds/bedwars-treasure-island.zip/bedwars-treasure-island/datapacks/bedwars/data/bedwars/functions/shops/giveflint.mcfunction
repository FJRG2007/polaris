give @s flint_and_steel{Damage:61,display:{Name:'[{"text":"Flint and Steel","italic":false,"color":"green"}]'},HideFlags:98}

clear @s iron_ingot 10
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

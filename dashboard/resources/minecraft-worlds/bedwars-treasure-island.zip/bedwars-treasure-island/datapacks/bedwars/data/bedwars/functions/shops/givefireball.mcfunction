give @s snowball{Unbreakable:1,display:{Name:'[{"text":"Fireball","italic":false,"color":"green"}]'},HideFlags:103} 1

clear @s iron_ingot 40
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

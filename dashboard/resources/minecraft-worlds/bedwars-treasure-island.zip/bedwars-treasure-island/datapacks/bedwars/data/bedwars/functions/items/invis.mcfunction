execute as @a[nbt={ActiveEffects:[{Id:14}]}] at @s run scoreboard players set @s invis 1
execute as @a at @s if data entity @s {HurtTime:9s} run scoreboard players set @s invis 0
execute as @a at @s if data entity @s {HurtTime:9s} run effect clear @s invisibility
execute as @a[nbt=!{ActiveEffects:[{Id:14}]}] at @s run scoreboard players set @s invis 0
execute if score pregame phase matches 1 run effect clear @a invisibility
execute if score pregame phase matches 1 run effect clear @a jump_boost
execute if score pregame phase matches 1 run effect clear @a levitation
execute if score pregame phase matches 1 run effect clear @a speed


clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:leather_chestplate
clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:leather_helmet
clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:chainmail_boots
clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:chainmail_leggings
clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:iron_boots
clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:iron_leggings
clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:diamond_boots
clear @a[nbt={ActiveEffects:[{Id:14}]}] minecraft:diamond_leggings
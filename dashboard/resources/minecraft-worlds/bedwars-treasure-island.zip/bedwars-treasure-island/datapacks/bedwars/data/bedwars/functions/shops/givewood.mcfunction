give @s oak_planks{Unbreakable:1,display:{Name:'[{"text":"Wood","italic":false}]'},HideFlags:6,Null:0b} 16

clear @s gold_ingot 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

give @s shield{Unbreakable:1,display:{Name:'[{"text":"Shield","italic":false}]'},HideFlags:6,Null:0b} 1

clear @s gold_ingot 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

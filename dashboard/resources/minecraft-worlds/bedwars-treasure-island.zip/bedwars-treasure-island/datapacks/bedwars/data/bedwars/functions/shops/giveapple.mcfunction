give @s golden_apple{Unbreakable:1,display:{Name:'[{"text":"Golden Apple","italic":false,"color":"green"}]'},HideFlags:103} 1

clear @s gold_ingot 3

playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

execute as @a[tag=closed_gray_team_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_gray_team_shop] barrier

clear @a barrier

tag @a[tag=closed_gray_team_shop] remove closed_gray_team_shop
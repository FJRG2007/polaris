tag @a[tag=launched] remove launched
item replace entity @a[nbt={Inventory:[{id:"minecraft:netherite_boots",Slot:100b}]}] armor.feet with air
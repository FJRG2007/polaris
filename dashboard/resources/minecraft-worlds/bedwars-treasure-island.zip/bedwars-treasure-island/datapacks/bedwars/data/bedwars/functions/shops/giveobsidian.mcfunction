give @s obsidian{Unbreakable:1,display:{Name:'[{"text":"Obsidian","italic":false}]'},HideFlags:6,Null:0b} 4

clear @s emerald 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

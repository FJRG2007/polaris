scoreboard players set @s iron_armor 1
scoreboard players set @s chainmail_armor 0

clear @s gold_ingot 12
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

execute as @e[type=minecraft:armor_stand,tag=gray_trap] at @s run effect clear @a[team=!gray,distance=..7] invisibility
scoreboard players set @e[type=minecraft:armor_stand,tag=gray_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/gray_reset 10s
scoreboard players set 74e4ce11-4b2d-49db-bf7f-e4a83251e079 trap1 0
scoreboard players set @a[team=gray] trap1 0

title @a[team=gray] subtitle {"text":"","color":"red"}
title @a[team=gray] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=gray] ~ ~ ~ 1 0.5
execute as @a[tag=closed_pink_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_pink_shop] barrier

clear @a barrier

tag @a[tag=closed_pink_shop] remove closed_pink_shop
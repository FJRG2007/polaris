execute as @e[tag=red_item_shop,type=minecraft:chest_minecart] at @s run tag @a[distance=..6.9] add closed_red_shop

execute as @a[tag=closed_red_shop] at @s run tp @s ~ ~30 ~

schedule function bedwars:shops/redtpdown 2t

item replace entity @e[tag=red_item_shop,type=chest_minecart] container.26 with minecraft:barrier{display:{Name:'[{"text":"Close Menu","italic":false,"color":"red"}]'}}
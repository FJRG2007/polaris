give @s diamond_sword{Unbreakable:1,display:{Name:'[{"text":"Diamond Sword","italic":false}]'},HideFlags:6,Null:0b} 1

clear @s emerald 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

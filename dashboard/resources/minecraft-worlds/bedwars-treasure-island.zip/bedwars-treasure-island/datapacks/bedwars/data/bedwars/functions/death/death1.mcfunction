tp @a[team=green,tag=dead1] 98 61 -30 90 0
tp @a[team=yellow,tag=dead1] 98 61 30 90 0
tp @a[team=aqua,tag=dead1] 30 61 98 -180 0
tp @a[team=white,tag=dead1] -30 61 98 -180 0
tp @a[team=pink,tag=dead1] -98 61 30 -90 0
tp @a[team=gray,tag=dead1] -98 61 -30 -90 0
tp @a[team=red,tag=dead1] -30 61 -98 0 0
tp @a[team=blue,tag=dead1] 30 61 -98 0 0

execute as @a[tag=dead1] at @s if score @s wooden_axe_count matches 1 run scoreboard players set @s wooden_axe_count 0
execute as @a[tag=dead1] at @s if score @s stone_axe_count matches 1 run scoreboard players set @s wooden_axe_count 1
execute as @a[tag=dead1] at @s if score @s stone_axe_count matches 1 run scoreboard players set @s stone_axe_count 0
execute as @a[tag=dead1] at @s if score @s iron_axe_count matches 1 run scoreboard players set @s stone_axe_count 1
execute as @a[tag=dead1] at @s if score @s iron_axe_count matches 1 run scoreboard players set @s iron_axe_count 0
execute as @a[tag=dead1] at @s if score @s diamond_axe_count matches 1 run scoreboard players set @s iron_axe_count 1
execute as @a[tag=dead1] at @s if score @s diamond_axe_count matches 1 run scoreboard players set @s diamond_axe_count 0

execute as @a[tag=dead1] at @s if score @s wooden_pickaxe_count matches 1 run scoreboard players set @s wooden_pickaxe_count 0
execute as @a[tag=dead1] at @s if score @s golden_pickaxe_count matches 1 run scoreboard players set @s wooden_pickaxe_count 1
execute as @a[tag=dead1] at @s if score @s golden_pickaxe_count matches 1 run scoreboard players set @s golden_pickaxe_count 0
execute as @a[tag=dead1] at @s if score @s iron_pickaxe_count matches 1 run scoreboard players set @s golden_pickaxe_count 1
execute as @a[tag=dead1] at @s if score @s iron_pickaxe_count matches 1 run scoreboard players set @s iron_pickaxe_count 0
execute as @a[tag=dead1] at @s if score @s diamond_pickaxe_count matches 1 run scoreboard players set @s iron_pickaxe_count 1
execute as @a[tag=dead1] at @s if score @s diamond_pickaxe_count matches 1 run scoreboard players set @s diamond_pickaxe_count 0

clear @a[tag=dead1]
title @a[tag=dead1] clear



gamemode survival @a[tag=dead1]
tag @a[tag=dead1] remove dead1

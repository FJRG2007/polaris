scoreboard players set @s shears 1
clear @s iron_ingot 24
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

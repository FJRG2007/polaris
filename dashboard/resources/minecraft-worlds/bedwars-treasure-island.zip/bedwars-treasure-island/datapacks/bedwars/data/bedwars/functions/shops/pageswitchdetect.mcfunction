scoreboard players set @s pageturn 1
schedule function bedwars:shops/page_1_to_anything 1t
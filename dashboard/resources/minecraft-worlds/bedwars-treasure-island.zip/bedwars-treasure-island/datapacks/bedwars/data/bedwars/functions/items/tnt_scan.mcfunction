execute as @a[scores={tnt_placed=1}] at @s run summon minecraft:armor_stand ^ ^ ^ {Invulnerable:1,Invisible:1,Silent:1,Tags:["tntscan1"],NoGravity:1}
execute as @a[scores={tnt_placed=1}] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=tntscan1] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=tntscan1] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["tntscan2"],Silent:1,NoGravity:1}
execute as @e[tag=tntscan1,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=tntscan2] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=tntscan2] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["tntscan3"],Silent:1,NoGravity:1}
execute as @e[tag=tntscan2,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=tntscan3] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=tntscan3] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["tntscan4"],Silent:1,NoGravity:1}
execute as @e[tag=tntscan3,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=tntscan4] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=tntscan4] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["tntscan5"],Silent:1,NoGravity:1}
execute as @e[tag=tntscan4,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=tntscan5] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=tntscan5] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["tntscan6"],Silent:1,NoGravity:1}
execute as @e[tag=tntscan5,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=tntscan6] Rotation set from entity @s Rotation
execute as @e[type=armor_stand,tag=tntscan1] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["tntscan1"]}
execute as @e[type=armor_stand,tag=tntscan2] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["tntscan2"]}
execute as @e[type=armor_stand,tag=tntscan3] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["tntscan3"]}
execute as @e[type=armor_stand,tag=tntscan4] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["tntscan4"]}
execute as @e[type=armor_stand,tag=tntscan5] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["tntscan5"]}
execute as @e[type=armor_stand,tag=tntscan6] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["tntscan6"]}
execute as @e[type=minecraft:armor_stand,tag=tntscan1] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=tntscan1]
execute as @e[type=minecraft:armor_stand,tag=tntscan2] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=tntscan2]
execute as @e[type=minecraft:armor_stand,tag=tntscan3] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=tntscan3]
execute as @e[type=minecraft:armor_stand,tag=tntscan4] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=tntscan4]
execute as @e[type=minecraft:armor_stand,tag=tntscan5] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=tntscan5]
execute as @e[type=minecraft:armor_stand,tag=tntscan6] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=tntscan6]
execute as @e[type=minecraft:armor_stand,tag=tntscan1] at @s run kill @e[type=item_frame,distance=..2,tag=tntscan1]
execute as @e[type=minecraft:armor_stand,tag=tntscan2] at @s run kill @e[type=item_frame,distance=..2,tag=tntscan2]
execute as @e[type=minecraft:armor_stand,tag=tntscan3] at @s run kill @e[type=item_frame,distance=..2,tag=tntscan3]
execute as @e[type=minecraft:armor_stand,tag=tntscan4] at @s run kill @e[type=item_frame,distance=..2,tag=tntscan4]
execute as @e[type=minecraft:armor_stand,tag=tntscan5] at @s run kill @e[type=item_frame,distance=..2,tag=tntscan5]
execute as @e[type=minecraft:armor_stand,tag=tntscan6] at @s run kill @e[type=item_frame,distance=..2,tag=tntscan6]
execute as @e[tag=tntscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run summon tnt ~ ~ ~ {Fuse:80}
execute as @e[tag=tntscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run setblock ~ ~ ~ air
execute as @e[tag=tntscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run summon tnt ~ ~1 ~ {Fuse:80}
execute as @e[tag=tntscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run setblock ~ ~1 ~ air
execute as @e[tag=tntscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run summon tnt ~ ~2 ~ {Fuse:80}
execute as @e[tag=tntscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run setblock ~ ~2 ~ air
execute as @e[tag=tntscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run summon tnt ~ ~ ~ {Fuse:80}
execute as @e[tag=tntscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run setblock ~ ~ ~ air
execute as @e[tag=tntscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run summon tnt ~ ~1 ~ {Fuse:80}
execute as @e[tag=tntscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run setblock ~ ~1 ~ air
execute as @e[tag=tntscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run summon tnt ~ ~2 ~ {Fuse:80}
execute as @e[tag=tntscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run setblock ~ ~2 ~ air
execute as @e[tag=tntscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run summon tnt ~ ~ ~ {Fuse:80}
execute as @e[tag=tntscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run setblock ~ ~ ~ air
execute as @e[tag=tntscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run summon tnt ~ ~1 ~ {Fuse:80}
execute as @e[tag=tntscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run setblock ~ ~1 ~ air
execute as @e[tag=tntscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run summon tnt ~ ~2 ~ {Fuse:80}
execute as @e[tag=tntscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run setblock ~ ~2 ~ air
execute as @e[tag=tntscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run summon tnt ~ ~ ~ {Fuse:80}
execute as @e[tag=tntscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run setblock ~ ~ ~ air
execute as @e[tag=tntscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run summon tnt ~ ~1 ~ {Fuse:80}
execute as @e[tag=tntscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run setblock ~ ~1 ~ air
execute as @e[tag=tntscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run summon tnt ~ ~2 ~ {Fuse:80}
execute as @e[tag=tntscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run setblock ~ ~2 ~ air
execute as @e[tag=tntscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run summon tnt ~ ~ ~ {Fuse:80}
execute as @e[tag=tntscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ tnt run setblock ~ ~ ~ air
execute as @e[tag=tntscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run summon tnt ~ ~1 ~ {Fuse:80}
execute as @e[tag=tntscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ tnt run setblock ~ ~1 ~ air
execute as @e[tag=tntscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run summon tnt ~ ~2 ~ {Fuse:80}
execute as @e[tag=tntscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ tnt run setblock ~ ~2 ~ air
kill @e[type=armor_stand,tag=tntscan1]
kill @e[type=armor_stand,tag=tntscan2]
kill @e[type=armor_stand,tag=tntscan3]
kill @e[type=armor_stand,tag=tntscan4]
kill @e[type=armor_stand,tag=tntscan5]
kill @e[type=armor_stand,tag=tntscan6]
scoreboard players set @a tnt_placed 0

##Fireball
execute as @e[type=minecraft:snowball] at @s run tag @s add fireball
execute as @e[type=minecraft:snowball,tag=fireball] at @s run summon minecraft:fireball ~ ~ ~ {ExplosionPower:2}
execute as @e[type=minecraft:snowball] at @s run data modify entity @e[type=minecraft:fireball,limit=1,sort=nearest] Motion set from entity @s Motion
execute as @e[type=minecraft:snowball] at @s run data modify entity @e[type=minecraft:fireball,limit=1,sort=nearest] power set from entity @s Motion
kill @e[type=minecraft:snowball,tag=fireball]
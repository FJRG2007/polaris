scoreboard players set gray message 1
playsound minecraft:entity.ender_dragon.growl master @a 0 100 0 1 1 1
tellraw @a ["",{"text":"BED DESTRUCTION >","bold":true,"color":"white"},{"text":" Gray Bed","color":"gray"},{"text":" was destroyed by ","color":"gray"},{"selector":"@a[scores={grayBedBroken=1}]","color":"dark_red"}]
title @a subtitle {"text":"You will no longer respawn!","color":"white"}
title @a[team=gray] title {"text":"Bed Destroyed","color":"red"}

execute as @a[tag=closed_green_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_green_shop] barrier

clear @a barrier

tag @a[tag=closed_green_shop] remove closed_green_shop
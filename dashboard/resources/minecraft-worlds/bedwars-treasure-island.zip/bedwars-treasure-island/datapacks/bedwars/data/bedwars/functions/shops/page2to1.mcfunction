execute as @e[scores={ShopPage=1..}] at @s unless entity @s[nbt={Items:[{Slot:18b,id:"minecraft:nether_star"}]}] run scoreboard players set @s ShopPage 1

item replace entity @e[type=minecraft:chest_minecart,scores={ShopPage=1}] container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b,HideFlags:2}

item replace entity @e[type=minecraft:chest_minecart,scores={ShopPage=1}] container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b,HideFlags:2}

item replace entity @e[type=minecraft:chest_minecart,scores={ShopPage=1}] container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b,HideFlags:2}

item replace entity @e[type=minecraft:chest_minecart,scores={ShopPage=1}] container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b,HideFlags:2}

item replace entity @e[type=minecraft:chest_minecart,scores={ShopPage=1}] container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b,HideFlags:2}

item replace entity @e[type=minecraft:chest_minecart,scores={ShopPage=1}] container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b,HideFlags:2}

item replace entity @e[type=minecraft:chest_minecart,scores={ShopPage=1}] container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b,HideFlags:2}
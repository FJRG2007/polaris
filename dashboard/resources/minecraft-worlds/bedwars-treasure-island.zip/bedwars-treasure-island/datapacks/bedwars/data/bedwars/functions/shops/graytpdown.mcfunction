execute as @a[tag=closed_gray_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_gray_shop] barrier

clear @a barrier

tag @a[tag=closed_gray_shop] remove closed_gray_shop
execute if entity @s[team=blue] run give @s blue_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16
execute if entity @s[team=red] run give @s red_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16
execute if entity @s[team=green] run give @s lime_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16
execute if entity @s[team=yellow] run give @s yellow_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16
execute if entity @s[team=pink] run give @s pink_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16
execute if entity @s[team=aqua] run give @s cyan_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16
execute if entity @s[team=gray] run give @s gray_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16
execute if entity @s[team=white] run give @s white_wool{Unbreakable:1,display:{Name:'[{"text":"Wool","italic":false}]'},HideFlags:6,Null:0b} 16

clear @s iron_ingot 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

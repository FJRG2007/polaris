scoreboard players set @e[type=minecraft:armor_stand,tag=gray_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=gray_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=gray_team_gen] em 60
function bedwars:events/gen_graymanage

scoreboard players set @e[type=minecraft:armor_stand,tag=pink_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=pink_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=pink_team_gen] em 60
function bedwars:events/gen_pinkmanage

scoreboard players set @e[type=minecraft:armor_stand,tag=red_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=red_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=red_team_gen] em 60
function bedwars:events/gen_redmanage

scoreboard players set @e[type=minecraft:armor_stand,tag=blue_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=blue_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=blue_team_gen] em 60
function bedwars:events/gen_bluemanage

scoreboard players set @e[type=minecraft:armor_stand,tag=white_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=white_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=white_team_gen] em 60
function bedwars:events/gen_whitemanage

scoreboard players set @e[type=minecraft:armor_stand,tag=aqua_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=aqua_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=aqua_team_gen] em 60
function bedwars:events/gen_aquamanage

scoreboard players set @e[type=minecraft:armor_stand,tag=green_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=green_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=green_team_gen] em 60
function bedwars:events/gen_greenmanage

scoreboard players set @e[type=minecraft:armor_stand,tag=yellow_team_gen] forge 0
scoreboard players set @e[type=minecraft:armor_stand,tag=yellow_team_gen] gold 4
scoreboard players set @e[type=minecraft:armor_stand,tag=yellow_team_gen] em 60
function bedwars:events/gen_yellowmanage
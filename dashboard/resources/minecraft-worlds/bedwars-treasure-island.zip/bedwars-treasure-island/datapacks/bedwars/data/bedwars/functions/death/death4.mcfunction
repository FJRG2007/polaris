gamemode spectator @s
tag @a[tag=dead4] add dead3
tag @a[tag=dead4] remove dead4

title @a[tag=dead3] title {"text":"You Died!","color":"red"}
title @a[tag=dead3] subtitle {"text":"Respawning in 3","color":"red"}

schedule function bedwars:death/death3 1s
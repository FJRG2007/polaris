##---------------------------------------------------------------------------------------------------------------------
##Minecarts to positions
tp @e[tag=blue_item_shop,type=minecraft:chest_minecart,limit=1] 35 63 -95
tp 9b50b175-8f74-4b1f-9001-c056c81cb22f -25 63 -95
tp @e[tag=gray_item_shop,type=minecraft:chest_minecart,limit=1] -95 63 -35
tp @e[tag=pink_item_shop,type=minecraft:chest_minecart,limit=1] -95 63 25
tp @e[tag=white_item_shop,type=minecraft:chest_minecart,limit=1] -35 63 95
tp @e[tag=aqua_item_shop,type=minecraft:chest_minecart,limit=1] 25 63 95
tp @e[tag=yellow_item_shop,type=minecraft:chest_minecart,limit=1] 95 63 35
tp @e[tag=green_item_shop,type=minecraft:chest_minecart,limit=1] 95 63 -25

tp dbc7cab8-fad6-4e03-a806-df0fbc407fa8 -36 63.1 -94
tp @e[tag=blue_team_shop,type=minecraft:chest_minecart,limit=1] 24 63.1 -94
tp @e[tag=green_team_shop,type=minecraft:chest_minecart,limit=1] 94 63.1 -36
tp @e[tag=yellow_team_shop,type=minecraft:chest_minecart,limit=1] 94 63.1 24
tp @e[tag=aqua_team_shop,type=minecraft:chest_minecart,limit=1] 36 63.1 94
tp @e[tag=white_team_shop,type=minecraft:chest_minecart,limit=1] -24 63.1 94
tp @e[tag=pink_team_shop,type=minecraft:chest_minecart,limit=1] -94 63.1 36
tp @e[tag=gray_team_shop,type=minecraft:chest_minecart,limit=1] -94 63.1 -24


execute unless entity @e[tag=blue_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=blue_item_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_shop

execute unless entity @e[tag=red_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s run function bedwars:shops/close_red_shop

execute unless entity @e[tag=gray_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=gray_item_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_gray_shop

execute unless entity @e[tag=pink_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=pink_item_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_pink_shop

execute unless entity @e[tag=white_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=white_item_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_white_shop

execute unless entity @e[tag=aqua_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=aqua_item_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_aqua_shop

execute unless entity @e[tag=yellow_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=yellow_item_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_yellow_shop

execute unless entity @e[tag=green_item_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=green_item_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_green_shop


execute unless entity @e[tag=red_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as dbc7cab8-fad6-4e03-a806-df0fbc407fa8 at @s run function bedwars:shops/close_red_team_shop

execute unless entity @e[tag=blue_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=blue_team_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_blue_team_shop

execute unless entity @e[tag=green_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=green_team_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_green_team_shop

execute unless entity @e[tag=yellow_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=yellow_team_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_yello_team_shop

execute unless entity @e[tag=gray_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=gray_team_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_gray_team_shop

execute unless entity @e[tag=pink_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=pink_team_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_pink_team_shop

execute unless entity @e[tag=white_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=white_team_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_white_team_shop

execute unless entity @e[tag=aqua_team_shop,type=minecraft:chest_minecart,limit=1,nbt={Items:[{Slot:26b,id:"minecraft:barrier"}]}] as @e[tag=aqua_team_shop,type=minecraft:chest_minecart] at @s run function bedwars:shops/close_aqua_team_shop


##-----------------------------------------------------------------------------------------------------------------------
##item clears
clear @a minecraft:barrier{display:{Name:'[{"text":"Close Menu","italic":false,"color":"red"}]'}}
clear @a nether_star
clear @a minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}
clear @a minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b,HideFlags:2}
clear @a minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b,HideFlags:2}
clear @a minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b,HideFlags:2}
clear @a minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b,HideFlags:2}
clear @a minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}
clear @a minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}
clear @a minecraft:gray_stained_glass_pane{display:{Name:'[{"text":"","italic":false}]'}}
##-----------------------------------------------------------------------------------------------------------------------
##Currency Counter

execute as @a store result score @s iron_count run clear @s minecraft:iron_ingot 0
execute as @a store result score @s gold_count run clear @s minecraft:gold_ingot 0
execute as @a store result score @s dia_count run clear @s minecraft:diamond 0
execute as @a store result score @s em_count run clear @s minecraft:emerald 0
##-----------------------------------------------------------------------------------------------------------------------
##Other Item Counters

##execute as @a store result score @s wooden_axe_count run clear @s wooden_axe{Unbreakable:1,display:{Name:'[{"text":"Wooden Axe","italic":false,"color":"green"}]'},HideFlags:103} 0
##execute as @a store result score @s stone_axe_count run clear @s stone_axe{Unbreakable:1,display:{Name:'[{"text":"Stone Axe","italic":false,"color":"green"}]'},HideFlags:103} 0
##execute as @a store result score @s iron_axe_count run clear @s iron_axe{Unbreakable:1,display:{Name:'[{"text":"Iron Axe","italic":false,"color":"green"}]'},HideFlags:103} 0
##execute as @a store result score @s diamond_axe_count run clear @s diamond_axe{Unbreakable:1,display:{Name:'[{"text":"Diamond Axe","italic":false,"color":"green"}]'},HideFlags:103} 0
##execute as @a store result score @s wooden_pickaxe_count run clear @s wooden_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Wooden Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 0
##execute as @a store result score @s gold_pickaxe_count run clear @s golden_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Golden Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 0
##execute as @a store result score @s iron_pickaxe_count run clear @s iron_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Iron Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 0
##execute as @a store result score @s diamond_pickaxe_count run clear @s diamond_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Diamond Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 0
execute as @a store result score @s shears run clear @s shears{Unbreakable:1,display:{Name:'[{"text":"Shears","italic":false,"color":"green"}]'},HideFlags:103} 0

##-----------------------------------------------------------------------------------------------------------------------
##Detect If Shop Is Looked At

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=blue_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set BlueItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=blue_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set BlueItemShop ShopLookedAt 0

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=red_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set RedItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=red_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set RedItemShop ShopLookedAt 0

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=gray_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set GrayItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=gray_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set GrayItemShop ShopLookedAt 0

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=pink_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set PinkItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=pink_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set PinkItemShop ShopLookedAt 0

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=white_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set WhiteItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=white_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set WhiteItemShop ShopLookedAt 0

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=aqua_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set AquaItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=aqua_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set AquaItemShop ShopLookedAt 0

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=yellow_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set YellowItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=yellow_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set YellowItemShop ShopLookedAt 0

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=green_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 if entity @s[distance=..0.3] run scoreboard players set GreenItemShop ShopLookedAt 1

execute as @a at @s anchored eyes facing entity @e[sort=nearest,limit=1,type=minecraft:chest_minecart,distance=..6,tag=green_item_shop] eyes anchored feet positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^-1 unless entity @s[distance=..0.3] run scoreboard players set GreenItemShop ShopLookedAt 0

##-----------------------------------------------------------------------------------------------------------------------

##Set Closed Shops To Page 1
execute if score BlueItemShop ShopLookedAt matches 0 run scoreboard players set 203bd4c0-3534-470b-8612-0932fe1ded3d ShopPage 1

execute if score BlueItemShop ShopLookedAt matches 0 as 203bd4c0-3534-470b-8612-0932fe1ded3d at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score BlueItemShop ShopLookedAt matches 0 as 203bd4c0-3534-470b-8612-0932fe1ded3d at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score BlueItemShop ShopLookedAt matches 0 as 203bd4c0-3534-470b-8612-0932fe1ded3d at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score BlueItemShop ShopLookedAt matches 0 as 203bd4c0-3534-470b-8612-0932fe1ded3d at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score BlueItemShop ShopLookedAt matches 0 as 203bd4c0-3534-470b-8612-0932fe1ded3d at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score BlueItemShop ShopLookedAt matches 0 as 203bd4c0-3534-470b-8612-0932fe1ded3d at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score BlueItemShop ShopLookedAt matches 0 as 203bd4c0-3534-470b-8612-0932fe1ded3d at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}

execute if score RedItemShop ShopLookedAt matches 0 run scoreboard players set 9b50b175-8f74-4b1f-9001-c056c81cb22f ShopPage 1

execute if score RedItemShop ShopLookedAt matches 0 as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score RedItemShop ShopLookedAt matches 0 as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score RedItemShop ShopLookedAt matches 0 as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score RedItemShop ShopLookedAt matches 0 as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score RedItemShop ShopLookedAt matches 0 as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score RedItemShop ShopLookedAt matches 0 as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score RedItemShop ShopLookedAt matches 0 as 9b50b175-8f74-4b1f-9001-c056c81cb22f at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}

##-----------------------------------------------------------------------------------------------------------------------
execute if score GrayItemShop ShopLookedAt matches 0 run scoreboard players set db4d9cae-8756-486f-9171-ed99fe55c6f1 ShopPage 1

execute if score GrayItemShop ShopLookedAt matches 0 as db4d9cae-8756-486f-9171-ed99fe55c6f1 at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score GrayItemShop ShopLookedAt matches 0 as db4d9cae-8756-486f-9171-ed99fe55c6f1 at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score GrayItemShop ShopLookedAt matches 0 as db4d9cae-8756-486f-9171-ed99fe55c6f1 at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score GrayItemShop ShopLookedAt matches 0 as db4d9cae-8756-486f-9171-ed99fe55c6f1 at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score GrayItemShop ShopLookedAt matches 0 as db4d9cae-8756-486f-9171-ed99fe55c6f1 at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score GrayItemShop ShopLookedAt matches 0 as db4d9cae-8756-486f-9171-ed99fe55c6f1 at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score GrayItemShop ShopLookedAt matches 0 as db4d9cae-8756-486f-9171-ed99fe55c6f1 at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}
##-----------------------------------------------------------------------------------------------------------------------
execute if score PinkItemShop ShopLookedAt matches 0 run scoreboard players set 6843ce41-372e-4b7f-891f-44073f2c547b ShopPage 1

execute if score PinkItemShop ShopLookedAt matches 0 as 6843ce41-372e-4b7f-891f-44073f2c547b at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score PinkItemShop ShopLookedAt matches 0 as 6843ce41-372e-4b7f-891f-44073f2c547b at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score PinkItemShop ShopLookedAt matches 0 as 6843ce41-372e-4b7f-891f-44073f2c547b at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score PinkItemShop ShopLookedAt matches 0 as 6843ce41-372e-4b7f-891f-44073f2c547b at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score PinkItemShop ShopLookedAt matches 0 as 6843ce41-372e-4b7f-891f-44073f2c547b at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score PinkItemShop ShopLookedAt matches 0 as 6843ce41-372e-4b7f-891f-44073f2c547b at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score PinkItemShop ShopLookedAt matches 0 as 6843ce41-372e-4b7f-891f-44073f2c547b at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}
##-----------------------------------------------------------------------------------------------------------------------
execute if score WhiteItemShop ShopLookedAt matches 0 run scoreboard players set bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 ShopPage 1

execute if score WhiteItemShop ShopLookedAt matches 0 as bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score WhiteItemShop ShopLookedAt matches 0 as bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score WhiteItemShop ShopLookedAt matches 0 as bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score WhiteItemShop ShopLookedAt matches 0 as bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score WhiteItemShop ShopLookedAt matches 0 as bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score WhiteItemShop ShopLookedAt matches 0 as bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score WhiteItemShop ShopLookedAt matches 0 as bdda5d88-b7bc-461e-b1ad-cf0aa9f2fcf0 at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}
##-----------------------------------------------------------------------------------------------------------------------
execute if score AquaItemShop ShopLookedAt matches 0 run scoreboard players set 75144b0b-71db-428d-b64a-1eeb95a6eb58 ShopPage 1

execute if score AquaItemShop ShopLookedAt matches 0 as 75144b0b-71db-428d-b64a-1eeb95a6eb58 at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score AquaItemShop ShopLookedAt matches 0 as 75144b0b-71db-428d-b64a-1eeb95a6eb58 at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score AquaItemShop ShopLookedAt matches 0 as 75144b0b-71db-428d-b64a-1eeb95a6eb58 at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score AquaItemShop ShopLookedAt matches 0 as 75144b0b-71db-428d-b64a-1eeb95a6eb58 at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score AquaItemShop ShopLookedAt matches 0 as 75144b0b-71db-428d-b64a-1eeb95a6eb58 at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score AquaItemShop ShopLookedAt matches 0 as 75144b0b-71db-428d-b64a-1eeb95a6eb58 at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score AquaItemShop ShopLookedAt matches 0 as 75144b0b-71db-428d-b64a-1eeb95a6eb58 at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}
##----------------------------------------------------------------------------------------------------------------------
execute if score YellowItemShop ShopLookedAt matches 0 run scoreboard players set 07c291ea-2a5d-4af7-875b-10d11fd4beb5 ShopPage 1

execute if score YellowItemShop ShopLookedAt matches 0 as 07c291ea-2a5d-4af7-875b-10d11fd4beb5 at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score YellowItemShop ShopLookedAt matches 0 as 07c291ea-2a5d-4af7-875b-10d11fd4beb5 at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score YellowItemShop ShopLookedAt matches 0 as 07c291ea-2a5d-4af7-875b-10d11fd4beb5 at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score YellowItemShop ShopLookedAt matches 0 as 07c291ea-2a5d-4af7-875b-10d11fd4beb5 at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score YellowItemShop ShopLookedAt matches 0 as 07c291ea-2a5d-4af7-875b-10d11fd4beb5 at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score YellowItemShop ShopLookedAt matches 0 as 07c291ea-2a5d-4af7-875b-10d11fd4beb5 at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score YellowItemShop ShopLookedAt matches 0 as 07c291ea-2a5d-4af7-875b-10d11fd4beb5 at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}
##----------------------------------------------------------------------------------------------------------------------
execute if score GreenItemShop ShopLookedAt matches 0 run scoreboard players set dd1132e3-bb61-43e5-bd86-35de73bf49bb ShopPage 1

execute if score GreenItemShop ShopLookedAt matches 0 as dd1132e3-bb61-43e5-bd86-35de73bf49bb at @s if score @s ShopPage matches 1 run item replace entity @s container.10 with minecraft:terracotta{display:{Name:'[{"text":"Blocks","italic":false}]'},Null:1b}

execute if score GreenItemShop ShopLookedAt matches 0 as dd1132e3-bb61-43e5-bd86-35de73bf49bb at @s if score @s ShopPage matches 1 run item replace entity @s container.11 with minecraft:golden_sword{display:{Name:'[{"text":"Weapons","italic":false}]'},Null:1b}

execute if score GreenItemShop ShopLookedAt matches 0 as dd1132e3-bb61-43e5-bd86-35de73bf49bb at @s if score @s ShopPage matches 1 run item replace entity @s container.12 with minecraft:chainmail_boots{display:{Name:'[{"text":"Armor","italic":false}]'},Null:1b}

execute if score GreenItemShop ShopLookedAt matches 0 as dd1132e3-bb61-43e5-bd86-35de73bf49bb at @s if score @s ShopPage matches 1 run item replace entity @s container.13 with minecraft:stone_pickaxe{display:{Name:'[{"text":"Tools","italic":false}]'},Null:1b}

execute if score GreenItemShop ShopLookedAt matches 0 as dd1132e3-bb61-43e5-bd86-35de73bf49bb at @s if score @s ShopPage matches 1 run item replace entity @s container.14 with minecraft:trident{display:{Name:'[{"text":"Tridents","italic":false}]'},Null:1b}

execute if score GreenItemShop ShopLookedAt matches 0 as dd1132e3-bb61-43e5-bd86-35de73bf49bb at @s if score @s ShopPage matches 1 run item replace entity @s container.15 with minecraft:brewing_stand{display:{Name:'[{"text":"Potions","italic":false}]'},Null:1b}

execute if score GreenItemShop ShopLookedAt matches 0 as dd1132e3-bb61-43e5-bd86-35de73bf49bb at @s if score @s ShopPage matches 1 run item replace entity @s container.16 with minecraft:tnt{display:{Name:'[{"text":"Utility","italic":false}]'},Null:1b}
##----------------------------------------------------------------------------------------------------------------------
##UI Pages
##  Categories- 1
##  Blocks- 2
##  Weapons- 3
##  Tools- 4
##  Tridents- 5
##  Potions- 6
##  Utility- 7
##----------------------------------------------------------------------------------------------------------------------
  
execute as @e[type=chest_minecart,scores={ShopPage=1}] at @s unless entity @s[nbt={Items:[{Slot:10b,id:"minecraft:terracotta"}]}] run scoreboard players set @s pageturn 1

execute as @e[type=chest_minecart,scores={ShopPage=1}] at @s unless entity @s[nbt={Items:[{Slot:11b,id:"minecraft:golden_sword"}]}] run scoreboard players set @s pageturn 1

execute as @e[type=chest_minecart,scores={ShopPage=1}] at @s unless entity @s[nbt={Items:[{Slot:12b,id:"minecraft:chainmail_boots"}]}] run scoreboard players set @s pageturn 1

execute as @e[type=chest_minecart,scores={ShopPage=1}] at @s unless entity @s[nbt={Items:[{Slot:13b,id:"minecraft:stone_pickaxe"}]}] run scoreboard players set @s pageturn 1

execute as @e[type=chest_minecart,scores={ShopPage=1}] at @s unless entity @s[nbt={Items:[{Slot:14b,id:"minecraft:trident"}]}] run scoreboard players set @s pageturn 1

execute as @e[type=chest_minecart,scores={ShopPage=1}] at @s unless entity @s[nbt={Items:[{Slot:15b,id:"minecraft:brewing_stand"}]}] run scoreboard players set @s pageturn 1

execute as @e[type=chest_minecart,scores={ShopPage=1}] at @s unless entity @s[nbt={Items:[{Slot:16b,id:"minecraft:tnt"}]}] run scoreboard players set @s pageturn 1

execute as @e[type=chest_minecart,scores={ShopPage=1,pageturn=1}] at @s unless entity @s[nbt={Items:[{Slot:10b,id:"minecraft:terracotta"}]}] run scoreboard players set @s ShopPage 2

execute as @e[type=chest_minecart,scores={ShopPage=1,pageturn=1}] at @s unless entity @s[nbt={Items:[{Slot:11b,id:"minecraft:golden_sword"}]}] run scoreboard players set @s ShopPage 3

execute as @e[type=chest_minecart,scores={ShopPage=1,pageturn=1}] at @s unless entity @s[nbt={Items:[{Slot:12b,id:"minecraft:chainmail_boots"}]}] run scoreboard players set @s ShopPage 4

execute as @e[type=chest_minecart,scores={ShopPage=1,pageturn=1}] at @s unless entity @s[nbt={Items:[{Slot:13b,id:"minecraft:stone_pickaxe"}]}] run scoreboard players set @s ShopPage 5

execute as @e[type=chest_minecart,scores={ShopPage=1,pageturn=1}] at @s unless entity @s[nbt={Items:[{Slot:14b,id:"minecraft:trident"}]}] run scoreboard players set @s ShopPage 6

execute as @e[type=chest_minecart,scores={ShopPage=1,pageturn=1}] at @s unless entity @s[nbt={Items:[{Slot:15b,id:"minecraft:brewing_stand"}]}] run scoreboard players set @s ShopPage 7

execute as @e[type=chest_minecart,scores={ShopPage=1,pageturn=1}] at @s unless entity @s[nbt={Items:[{Slot:16b,id:"minecraft:tnt"}]}] run scoreboard players set @s ShopPage 8

execute as @e[type=chest_minecart,scores={ShopPage=1..,pageturn=0}] at @s unless entity @s[nbt={Items:[{Slot:18b,id:"minecraft:nether_star"}]}] run schedule function bedwars:shops/page2to1 1t

item replace entity @e[type=chest_minecart,scores={pageturn=1}] container.18 with nether_star{display:{Name:'[{"text":"Back","italic":false,"color":"light_purple"}]'}} 1

execute as @e[type=chest_minecart,scores={ShopPage=1..}] at @s if score @s pageturn matches 1 run scoreboard players set @s pageturn 0

#--------------------------------------------------------------------------------------------------------------
##PAGE 1
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=1,pageturn=0}] at @s run function bedwars:shops/page1

##--------------------------------------------------------------------------------------------------------------------
##PAGE 2
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=2,pageturn=0}] at @s run function bedwars:shops/page2

#--------------------------------------------------------------------------------------------------------------
##PAGE 3
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=3,pageturn=0}] at @s run function bedwars:shops/page3

#--------------------------------------------------------------------------------------------------------------
##PAGE 4
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=4,pageturn=0}] at @s run function bedwars:shops/page4

#--------------------------------------------------------------------------------------------------------------
##PAGE 5
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=5,pageturn=0}] at @s run function bedwars:shops/page5

#--------------------------------------------------------------------------------------------------------------
##PAGE 6
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=6,pageturn=0}] at @s run function bedwars:shops/page6

#--------------------------------------------------------------------------------------------------------------
##PAGE 7
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=7,pageturn=0}] at @s run function bedwars:shops/page7

#--------------------------------------------------------------------------------------------------------------
##PAGE 8
execute as @e[type=minecraft:chest_minecart,scores={ShopPage=8,pageturn=0}] at @s run function bedwars:shops/page8

#--------------------------------------------------------------------------------------------------------------
##PAGE 9
execute as @e[type=minecraft:chest_minecart,tag=team_shop] at @s run function bedwars:shops/page9
clear @a
scoreboard players set pregame phase 1
scoreboard players set ingame phase 0
tag @a remove player
tag @a remove spectator
schedule function bedwars:events/clearteams 1t
scoreboard players set @a blueBedBroken 0
scoreboard players set @a redBedBroken 0
scoreboard players set @a greenBedBroken 0
scoreboard players set @a pinkBedBroken 0
scoreboard players set @a cyanBedBroken 0
scoreboard players set @a grayBedBroken 0
scoreboard players set @a whiteBedBroken 0
scoreboard players set @a yellowBedBroken 0
gamemode adventure @a
setblock 91 62 -27 air
setblock 91 62 33 air
setblock 27 62 91 air
setblock -33 62 91 air
setblock -91 62 27 air
setblock -91 62 -33 air
setblock -27 62 -91 air
setblock 33 62 -91 air

kill @e[type=item]
function bedwars:events/stopphases
worldborder center 0 0
worldborder warning distance 10
item replace entity @a enderchest.0 with air
item replace entity @a enderchest.1 with air
item replace entity @a enderchest.2 with air
item replace entity @a enderchest.3 with air
item replace entity @a enderchest.4 with air
item replace entity @a enderchest.5 with air
item replace entity @a enderchest.6 with air
item replace entity @a enderchest.7 with air
item replace entity @a enderchest.8 with air
item replace entity @a enderchest.9 with air
item replace entity @a enderchest.10 with air
item replace entity @a enderchest.11 with air
item replace entity @a enderchest.12 with air
item replace entity @a enderchest.13 with air
item replace entity @a enderchest.14 with air
item replace entity @a enderchest.15 with air
item replace entity @a enderchest.16 with air
item replace entity @a enderchest.17 with air
item replace entity @a enderchest.18 with air
item replace entity @a enderchest.19 with air
item replace entity @a enderchest.20 with air
item replace entity @a enderchest.21 with air
item replace entity @a enderchest.22 with air
item replace entity @a enderchest.23 with air
item replace entity @a enderchest.24 with air
item replace entity @a enderchest.25 with air
item replace entity @a enderchest.26 with air
worldborder set 250
scoreboard players set border shrinking 0
function bedwars:events/reset_bed_messages
tag @a remove Eliminated
effect give @a minecraft:regeneration 1 255 true
scoreboard players reset @a eliminated
scoreboard players set gameover gameover 0
function bedwars:events/resetarmor
function bedwars:events/resettools
function bedwars:events/resetupgrades
function bedwars:events/map_reset
schedule function bedwars:lobby/spawnlobby 1t
tp @a 0 123 0 -90 0
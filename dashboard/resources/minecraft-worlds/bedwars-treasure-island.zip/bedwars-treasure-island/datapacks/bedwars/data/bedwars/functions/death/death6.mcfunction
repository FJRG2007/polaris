gamemode spectator @s

clear @s

execute if score ingame phase matches 1 if score green beds matches 0 run tag @a[team=green,tag=dead6] add Eliminated
execute if score ingame phase matches 1 if score yellow beds matches 0 run tag @a[team=yellow,tag=dead6] add Eliminated
execute if score ingame phase matches 1 if score cyan beds matches 0 run tag @a[team=aqua,tag=dead6] add Eliminated
execute if score ingame phase matches 1 if score white beds matches 0 run tag @a[team=white,tag=dead6] add Eliminated
execute if score ingame phase matches 1 if score pink beds matches 0 run tag @a[team=pink,tag=dead6] add Eliminated
execute if score ingame phase matches 1 if score gray beds matches 0 run tag @a[team=gray,tag=dead6] add Eliminated
execute if score ingame phase matches 1 if score red beds matches 0 run tag @a[team=red,tag=dead6] add Eliminated
execute if score ingame phase matches 1 if score blue beds matches 0 run tag @a[team=blue,tag=dead6] add Eliminated

tag @a[tag=!Eliminated,tag=dead6] add dead5
tag @s remove dead6
title @a[tag=dead5] title {"text":"You Died!","color":"red"}
title @a[tag=dead5] subtitle {"text":"Respawning in 5","color":"red"}

execute as @s at @s run schedule function bedwars:death/death5 1s


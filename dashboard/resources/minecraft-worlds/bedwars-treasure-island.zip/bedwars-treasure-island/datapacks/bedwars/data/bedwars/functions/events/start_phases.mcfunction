scoreboard players set phase game_phase 1
scoreboard players set time game_phase 360
function bedwars:events/phases
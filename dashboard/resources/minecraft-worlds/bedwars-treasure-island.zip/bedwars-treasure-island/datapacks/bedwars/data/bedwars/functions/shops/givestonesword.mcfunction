give @s stone_sword{Unbreakable:1,display:{Name:'[{"text":"Stone Sword","italic":false}]'},HideFlags:6,Null:0b} 1

clear @s iron_ingot 10
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

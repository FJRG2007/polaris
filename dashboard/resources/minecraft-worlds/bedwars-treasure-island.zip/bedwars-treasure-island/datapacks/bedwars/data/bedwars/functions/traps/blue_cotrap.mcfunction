execute as @e[type=minecraft:armor_stand,tag=blue_trap] at @s run effect give @a[team=blue,distance=..15] jump_boost 15 2 true
execute as @e[type=minecraft:armor_stand,tag=blue_trap] at @s run effect give @a[team=blue,distance=..15] speed 15 8 true
scoreboard players set @e[type=minecraft:armor_stand,tag=blue_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/blue_reset 15s
scoreboard players set 203bd4c0-3534-470b-8612-0932fe1ded3d trap1 0
scoreboard players set @a[team=blue] trap1 0
title @a[team=blue] subtitle {"text":"","color":"red"}
title @a[team=blue] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=blue] ~ ~ ~ 1 0.5
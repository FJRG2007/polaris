scoreboard players set @s iron_pickaxe_count 0
clear @s iron_pickaxe
scoreboard players set @s diamond_pickaxe_count 1
clear @s gold_ingot 12
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

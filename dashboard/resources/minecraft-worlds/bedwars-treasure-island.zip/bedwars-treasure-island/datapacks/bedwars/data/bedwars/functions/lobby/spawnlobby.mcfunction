setblock 0 120 13 structure_block{mode:"LOAD",posX:-11,posY:1,posZ:-23,name:"spawn",rotation:"NONE",mirror:"NONE"} replace
setblock 0 121 13 redstone_block
setblock 7 123 -4 minecraft:barrier
setblock 7 124 -4 barrier
setblock 0 120 13 air
setblock 0 121 13 air
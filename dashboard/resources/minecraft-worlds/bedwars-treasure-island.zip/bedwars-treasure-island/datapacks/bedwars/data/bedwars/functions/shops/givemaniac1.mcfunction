execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @a[team=red] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=red_team_shop] haste 1

execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @a[team=blue] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=blue_team_shop] haste 1

execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @a[team=green] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=green_team_shop] haste 1

execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @a[team=yellow] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] haste 1

execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @a[team=gray] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=gray_team_shop] haste 1

execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @a[team=pink] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=pink_team_shop] haste 1

execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @a[team=white] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=white_team_shop] haste 1

execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @a[team=aqua] haste 1
execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] haste 1

clear @s diamond 2
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

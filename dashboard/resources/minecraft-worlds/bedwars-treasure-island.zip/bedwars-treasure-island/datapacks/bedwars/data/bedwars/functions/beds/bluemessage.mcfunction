scoreboard players set blue message 1
playsound minecraft:entity.ender_dragon.growl master @a 0 100 0 1 1 1
tellraw @a ["",{"text":"BED DESTRUCTION >","bold":true,"color":"white"},{"text":" Blue Bed","color":"blue"},{"text":" was destroyed by ","color":"gray"},{"selector":"@a[scores={blueBedBroken=1}]","color":"dark_red"}]
title @a subtitle {"text":"You will no longer respawn!","color":"white"}
title @a[team=blue] title {"text":"Bed Destroyed","color":"red"}

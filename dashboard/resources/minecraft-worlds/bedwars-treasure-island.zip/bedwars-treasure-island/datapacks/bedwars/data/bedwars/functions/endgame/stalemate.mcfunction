scoreboard players set gameover gameover 1

title @a subtitle {"text":"Nobody Won :(","color":"white"}
title @a title {"text":"Stalemate","color":"gray"}

schedule function bedwars:events/end_game 4s
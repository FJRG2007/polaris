give @s trident{Unbreakable:1,display:{Name:'[{"text":"Trident (Loyalty I)","italic":false,"color":"green"}]'},Enchantments:[{id:loyalty,lvl:1}],HideFlags:103} 1

clear @s emerald 2
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

give @s end_stone{Unbreakable:1,display:{Name:'[{"text":"End Stone","italic":false}]'},HideFlags:6,Null:0b} 12

clear @s iron_ingot 24
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

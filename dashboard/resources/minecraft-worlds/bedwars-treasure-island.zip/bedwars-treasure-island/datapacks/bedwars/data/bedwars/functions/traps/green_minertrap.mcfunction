execute as @e[type=minecraft:armor_stand,tag=green_trap] at @s run effect give @p[team=!green] minecraft:mining_fatigue 10 1 true
scoreboard players set @e[type=minecraft:armor_stand,tag=green_trap,limit=1] trapcooldown 1
schedule function bedwars:traps/green_reset 15s
scoreboard players set 90da363b-f000-4726-a003-b41aea423dd8 trap1 0
scoreboard players set @a[team=green] trap1 0
title @a[team=green] subtitle {"text":"","color":"red"}
title @a[team=green] title {"text":"Trap Triggered","color":"red"}
playsound minecraft:entity.enderman.teleport master @a[team=green] ~ ~ ~ 1 0.5
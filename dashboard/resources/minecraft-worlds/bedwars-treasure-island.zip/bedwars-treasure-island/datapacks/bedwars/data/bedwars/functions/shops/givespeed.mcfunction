give @s potion{CustomPotionColor:4617661,display:{Name:'[{"text":"Speed II Potion (45s)","italic":false,"color":"green"}]'},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:1,Duration:900,Amplifier:1,ShowParticles:0b}]}

clear @s emerald 1
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

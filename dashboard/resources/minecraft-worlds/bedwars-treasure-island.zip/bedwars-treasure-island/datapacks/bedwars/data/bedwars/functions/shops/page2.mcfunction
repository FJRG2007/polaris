item replace entity @s container.0 with minecraft:air
item replace entity @s container.1 with minecraft:air
item replace entity @s container.2 with minecraft:air
item replace entity @s container.3 with minecraft:air
item replace entity @s container.4 with minecraft:air
item replace entity @s container.5 with minecraft:air
item replace entity @s container.6 with minecraft:air
item replace entity @s container.7 with minecraft:air
item replace entity @s container.8 with minecraft:air
item replace entity @s container.9 with minecraft:air
item replace entity @s container.10 with white_wool{display:{Name:'[{"text":"Wool","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Null:1b} 16
item replace entity @s container.11 with end_stone{display:{Name:'[{"text":"End Stone","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"24 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 12
item replace entity @s container.12 with oak_planks{display:{Name:'[{"text":"Wood","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 16
item replace entity @s container.13 with white_concrete{display:{Name:'[{"text":"Concrete","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"16 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 24
item replace entity @s container.14 with ladder{display:{Name:'[{"text":"Ladder","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 8
item replace entity @s container.15 with oak_leaves{display:{Name:'[{"text":"Waterlogged Leaves","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"A portable water source!","italic":false,"color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 2
item replace entity @s container.16 with obsidian{display:{Name:'[{"text":"Obsidian","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 4
item replace entity @s container.17 with minecraft:air
execute if score @s pageturn matches 1 run item replace entity @s container.18 with nether_star{display:{Name:'[{"text":"Back","italic":false,"color":"light_purple"}]'}} 1
item replace entity @s container.19 with minecraft:air
item replace entity @s container.20 with minecraft:air
item replace entity @s container.21 with minecraft:air
item replace entity @s container.22 with minecraft:air
item replace entity @s container.23 with minecraft:air
item replace entity @s container.24 with minecraft:air
item replace entity @s container.25 with minecraft:air
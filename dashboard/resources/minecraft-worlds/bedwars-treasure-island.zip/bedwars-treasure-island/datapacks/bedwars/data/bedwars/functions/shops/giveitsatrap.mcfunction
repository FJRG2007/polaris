execute as @e[scores={trap1=0..}] at @s if score @s trap1 matches 0 if score @s trap2 matches 1.. run scoreboard players operation @s trap1 >< @s trap2
execute as @e[scores={trap2=0..}] at @s if score @s trap2 matches 0 if score @s trap3 matches 1.. run scoreboard players operation @s trap1 >< @s trap2


execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=red] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=red_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=red] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=red_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop,scores={trap1=0}] run scoreboard players set @a[team=red] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=red_team_shop] trap1 1


execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=blue] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=blue_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=blue] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=blue_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop,scores={trap1=0}] run scoreboard players set @a[team=blue] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=blue_team_shop] trap1 1


execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=green] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=green_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=green] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=green_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop,scores={trap1=0}] run scoreboard players set @a[team=green] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=green_team_shop] trap1 1


execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=yellow] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=yellow] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop,scores={trap1=0}] run scoreboard players set @a[team=yellow] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] trap1 1


execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=gray] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=gray_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=gray] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=gray_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop,scores={trap1=0}] run scoreboard players set @a[team=gray] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=gray_team_shop] trap1 1


execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=pink] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=pink_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=pink] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=pink_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop,scores={trap1=0}] run scoreboard players set @a[team=pink] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=pink_team_shop] trap1 1


execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=white] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=white_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=white] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=white_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop,scores={trap1=0}] run scoreboard players set @a[team=white] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=white_team_shop] trap1 1


execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @a[team=aqua] trap3 1
execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop,scores={trap1=1..,trap2=1..}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] trap3 1

execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @a[team=aqua] trap2 1
execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop,scores={trap1=1..,trap2=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] trap2 1

execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop,scores={trap1=0}] run scoreboard players set @a[team=aqua] trap1 1
execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop,scores={trap1=0}] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] trap1 1

playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1



clear @s diamond 1

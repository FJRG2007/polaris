scoreboard players set red message 1
playsound minecraft:entity.ender_dragon.growl master @a 0 100 0 1 1 1
tellraw @a ["",{"text":"BED DESTRUCTION >","bold":true,"color":"white"},{"text":" Red Bed","color":"red"},{"text":" was destroyed by ","color":"gray"},{"selector":"@a[scores={redBedBroken=1}]","color":"dark_red"}]
title @a subtitle {"text":"You will no longer respawn!","color":"white"}
title @a[team=red] title {"text":"Bed Destroyed","color":"red"}
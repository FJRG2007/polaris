execute if score aqua teamplayerscount matches 1.. if score cyan beds matches 1 run team modify aqua_display suffix {"text":" ✓","color":"green"}
execute if score cyan beds matches 0 if score aqua teamplayerscount matches 2 run team modify aqua_display suffix {"text":" 2","color":"green"}
execute if score cyan beds matches 0 if score aqua teamplayerscount matches 1 run team modify aqua_display suffix {"text":" 1","color":"green"}
execute if score aqua teamplayerscount matches 0 run team modify aqua_display suffix {"text":" ✗","color":"red"}

execute if score white teamplayerscount matches 1.. if score white beds matches 1 run team modify white_display suffix {"text":" ✓","color":"green"}
execute if score white beds matches 0 if score white teamplayerscount matches 2 run team modify white_display suffix {"text":" 2","color":"green"}
execute if score white beds matches 0 if score white teamplayerscount matches 1 run team modify white_display suffix {"text":" 1","color":"green"}
execute if score white teamplayerscount matches 0 run team modify white_display suffix {"text":" ✗","color":"red"}

execute if score red teamplayerscount matches 1.. if score red beds matches 1 run team modify red_display suffix {"text":" ✓","color":"green"}
execute if score red beds matches 0 if score red teamplayerscount matches 2 run team modify red_display suffix {"text":" 2","color":"green"}
execute if score red beds matches 0 if score red teamplayerscount matches 1 run team modify red_display suffix {"text":" 1","color":"green"}
execute if score red teamplayerscount matches 0 run team modify red_display suffix {"text":" ✗","color":"red"}

execute if score blue teamplayerscount matches 1.. if score blue beds matches 1 run team modify blue_display suffix {"text":" ✓","color":"green"}
execute if score blue beds matches 0 if score blue teamplayerscount matches 2 run team modify blue_display suffix {"text":" 2","color":"green"}
execute if score blue beds matches 0 if score blue teamplayerscount matches 1 run team modify blue_display suffix {"text":" 1","color":"green"}
execute if score blue teamplayerscount matches 0 run team modify blue_display suffix {"text":" ✗","color":"red"}

execute if score pink teamplayerscount matches 1.. if score pink beds matches 1 run team modify pink_display suffix {"text":" ✓","color":"green"}
execute if score pink beds matches 0 if score pink teamplayerscount matches 2 run team modify pink_display suffix {"text":" 2","color":"green"}
execute if score pink beds matches 0 if score pink teamplayerscount matches 1 run team modify pink_display suffix {"text":" 1","color":"green"}
execute if score pink teamplayerscount matches 0 run team modify pink_display suffix {"text":" ✗","color":"red"}

execute if score gray teamplayerscount matches 1.. if score gray beds matches 1 run team modify gray_display suffix {"text":" ✓","color":"green"}
execute if score gray beds matches 0 if score gray teamplayerscount matches 2 run team modify gray_display suffix {"text":" 2","color":"green"}
execute if score gray beds matches 0 if score gray teamplayerscount matches 1 run team modify gray_display suffix {"text":" 1","color":"green"}
execute if score gray teamplayerscount matches 0 run team modify gray_display suffix {"text":" ✗","color":"red"}

execute if score yellow teamplayerscount matches 1.. if score yellow beds matches 1 run team modify yellow_display suffix {"text":" ✓","color":"green"}
execute if score yellow beds matches 0 if score yellow teamplayerscount matches 2 run team modify yellow_display suffix {"text":" 2","color":"green"}
execute if score yellow beds matches 0 if score yellow teamplayerscount matches 1 run team modify yellow_display suffix {"text":" 1","color":"green"}
execute if score yellow teamplayerscount matches 0 run team modify yellow_display suffix {"text":" ✗","color":"red"}

execute if score green teamplayerscount matches 1.. if score green beds matches 1 run team modify green_display suffix {"text":" ✓","color":"green"}
execute if score green beds matches 0 if score green teamplayerscount matches 2 run team modify green_display suffix {"text":" 2","color":"green"}
execute if score green beds matches 0 if score green teamplayerscount matches 1 run team modify green_display suffix {"text":" 1","color":"green"}
execute if score green teamplayerscount matches 0 run team modify green_display suffix {"text":" ✗","color":"red"}
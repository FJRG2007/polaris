##Purchasing
execute as @a at @s store success score @s bought_wool run clear @s white_wool{display:{Name:'[{"text":"Wool","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}}
execute as @a at @s store success score @s bought_endstone run clear @s end_stone{display:{Name:'[{"text":"End Stone","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"24 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}}
execute as @a at @s store success score @s bought_wood run clear @s oak_planks{display:{Name:'[{"text":"Wood","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}}
execute as @a at @s store success score @s bought_concrete run clear @s white_concrete{display:{Name:'[{"text":"Concrete","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"16 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}}
execute as @a at @s store success score @s bought_ladders run clear @s ladder{display:{Name:'[{"text":"Ladder","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}}
execute as @a at @s store success score @s bought_leaves run clear @s oak_leaves{display:{Name:'[{"text":"Waterlogged Leaves","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"A portable water source!","italic":false,"color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}}
execute as @a at @s store success score @s bought_obby run clear @s obsidian{display:{Name:'[{"text":"Obsidian","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_purple"},{"text":"4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}}

execute as @a at @s store success score @s bought_stone_sword run clear @s minecraft:stone_sword{display:{Name:'[{"text":"Stone Sword","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 10 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:2} 
execute as @a at @s store success score @s bought_iron_sword run clear @s minecraft:iron_sword{display:{Name:'[{"text":"Iron Sword","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"7 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:2}
execute as @a at @s store success score @s bought_diamond_sword run clear @s minecraft:diamond_sword{display:{Name:'[{"text":"Diamond Sword","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:2}
execute as @a at @s store success score @s bought_kb_stick run clear @s minecraft:stick{display:{Name:'[{"text":"Knockback (II) Stick","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"5 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{id:knockback,lvl:2}],HideFlags:1}
execute as @a at @s store success score @s bought_shield run clear @s minecraft:shield{Unbreakable:1,display:{Name:'[{"text":"Shield","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[],HideFlags:4}
execute as @a at @s store success score @s bought_rod run clear @s minecraft:fishing_rod{Unbreakable:1,display:{Name:'[{"text":"Fishing Rod","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"5 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[],HideFlags:4}
execute as @a at @s store success score @s bought_cannon run clear @s skeleton_spawn_egg{display:{Name:'[{"text":"Portable Cannon","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"40 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Place it down to spawn a cannon","italic":false,"color":"dark_purple"}]','[{"text":"turret to defend you","italic":false,"color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"CLick to Purchase!","italic":false,"color":"yellow"}]']}}

execute as @a at @s store success score @s bought_chain_armor run clear @s minecraft:chainmail_boots{Unbreakable:1,display:{Name:'[{"text":"Permanent Chainmail Armor","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"gold"},{"text":"40 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:6}
execute as @a at @s store success score @s bought_iron_armor run clear @s minecraft:iron_boots{Unbreakable:1,display:{Name:'[{"text":"Permanent Iron Armor","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 12 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:6}
execute as @a at @s store success score @s bought_dia_armor run clear @s minecraft:diamond_boots{Unbreakable:1,display:{Name:'[{"text":"Permanent Diamond Armor","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"6 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:6}

execute as @a at @s store success score @s bought_wooden_axe run clear @s wooden_axe{display:{Name:'[{"text":"Wooden Axe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"10 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_stone_axe run clear @s stone_axe{display:{Name:'[{"text":"Stone Axe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"20 Iron ","color":"white"},{"text":"+"},{"text":" ","color":"white"},{"text":"Wooden Axe","color":"green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_iron_axe run clear @s iron_axe{display:{Name:'[{"text":"Iron Axe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"8 Gold","color":"gold"},{"text":" ","color":"white"},{"text":"+"},{"text":" ","color":"white"},{"text":"Stone Axe","color":"green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_diamond_axe run clear @s diamond_axe{display:{Name:'[{"text":"Diamond Axe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"12 Gold","color":"gold"},{"text":" ","color":"white"},{"text":"+"},{"text":" ","color":"white"},{"text":"Iron Axe","color":"green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_wooden_pickaxe run clear @s minecraft:wooden_pickaxe{display:{Name:'[{"text":"Wooden Pickaxe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"10 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_golden_pickaxe run clear @s golden_pickaxe{display:{Name:'[{"text":"Golden Pickaxe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"20 Iron ","color":"white"},{"text":"+"},{"text":" Wooden Pickaxe","color":"green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_iron_pickaxe run clear @s iron_pickaxe{display:{Name:'[{"text":"Iron Pickaxe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"8 Gold","color":"gold"},{"text":" ","color":"white"},{"text":"+"},{"text":" Golden Pickaxe","color":"green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_diamond_pickaxe run clear @s diamond_pickaxe{display:{Name:'[{"text":"Diamond Pickaxe","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"12 Gold","color":"gold"},{"text":" ","color":"white"},{"text":"+"},{"text":" Iron Pickaxe","color":"green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_shears run clear @s shears{display:{Name:'[{"text":"Permanent Shears","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"24 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}
execute as @a at @s store success score @s bought_flint run clear @s flint_and_steel{Damage:61,display:{Name:'[{"text":"Flint and Steel","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"10 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"3 uses","italic":false,"color":"dark_purple"},{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:98}

execute as @a at @s store success score @s bought_trident run clear @s trident{Unbreakable:1,display:{Name:'[{"text":"Trident","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"3 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:102}
execute as @a at @s store success score @s bought_loyalty_trident run clear @s trident{Unbreakable:1,display:{Name:'[{"text":"Trident (Loyalty I)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"2 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{id:loyalty,lvl:1}],HideFlags:103}
execute as @a at @s store success score @s bought_riptide_trident run clear @s trident{Unbreakable:1,display:{Name:'[{"text":"Trident (Riptide II)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{id:riptide,lvl:2}],HideFlags:103} 1


execute as @a at @s store success score @s bought_popup_tower run clear @s note_block{Unbreakable:1,display:{Name:'[{"text":"Pop-Up Tower","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 24 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
execute as @a at @s store success score @s bought_tnt run clear @s tnt{Unbreakable:1,display:{Name:'[{"text":"TNT","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 4 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
execute as @a at @s store success score @s bought_fireball run clear @s fire_charge{Unbreakable:1,display:{Name:'[{"text":"Fireball","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 40 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
execute as @a at @s store success score @s bought_apple run clear @s golden_apple{Unbreakable:1,display:{Name:'[{"text":"Golden Apple","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"white"},{"text":"3 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
execute as @a at @s store success score @s bought_epearl run clear @s ender_pearl{Unbreakable:1,display:{Name:'[{"text":"Ender Pearl","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:103} 1
execute as @a at @s store success score @s bought_golem run clear @s iron_golem_spawn_egg{Unbreakable:1,display:{Name:'[{"text":"Iron Golem Egg","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" ","color":"dark_green"},{"text":"150 Iron","color":"white"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"This feature has not been implemented yet!","italic":false,"color":"red"}]']},HideFlags:103} 1
execute as @a at @s store success score @s bought_bridge_egg run clear @s egg{display:{Name:'[{"text":"Cloud Jumper","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"6 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"Right-Click to launch into the sky","italic":false,"color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']}} 1

execute as @a at @s store success score @s bought_invis run clear @s potion{CustomPotionColor:10322096,display:{Name:'[{"text":"Invisibility Potion (30s)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 2 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:14,Duration:600,Amplifier:1,ShowParticles:0b}]}
execute as @a at @s store success score @s bought_jump run clear @s potion{CustomPotionColor:4617661,display:{Name:'[{"text":"Speed II Potion (45s)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 1 Emerald","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:1,Duration:900,Amplifier:1,ShowParticles:0b}]}
execute as @a at @s store success score @s bought_speed run clear @s potion{CustomPotionColor:65293,display:{Name:'[{"text":"Jump Boost V Potion (45s)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost:","italic":false,"color":"gray"},{"text":" 1 Emerald","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:8,Duration:900,Amplifier:4,ShowParticles:0b}]}





execute as @a at @s store success score @s bought_sharpness run clear @s iron_sword{display:{Name:'[{"text":"Sharpened Swords","italic":false,"color":"red"}]'},HideFlags:2}

execute as @a at @s store success score @s already_own_sharpness run clear @s iron_sword{display:{Name:'[{"text":"Sharpened Swords","italic":false,"color":"green"}]'},HideFlags:2}


execute as @a at @s store success score @s bought_prot1 run clear @s iron_chestplate{display:{Name:'[{"text":"Reinforced Armor I","italic":false,"color":"red"}]'},HideFlags:2}

execute as @a at @s store success score @s bought_prot2 run clear @s iron_chestplate{display:{Name:'[{"text":"Reinforced Armor II","italic":false,"color":"red"}]'},HideFlags:2}

execute as @a at @s store success score @s bought_prot3 run clear @s iron_chestplate{display:{Name:'[{"text":"Reinforced Armor III","italic":false,"color":"red"}]'},HideFlags:2}

execute as @a at @s store success score @s bought_prot4 run clear @s iron_chestplate{display:{Name:'[{"text":"Reinforced Armor IV","italic":false,"color":"red"}]'},HideFlags:2}

execute as @a at @s store success score @s prot_max run clear @s iron_chestplate{display:{Name:'[{"text":"Reinforced Armor (MAX)","italic":false,"color":"red"}]'},HideFlags:2}


execute as @a at @s store success score @s bought_forge1 run clear @s furnace{display:{Name:'[{"text":"Iron Forge","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s bought_forge2 run clear @s furnace{display:{Name:'[{"text":"Golden Forge","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s bought_forge3 run clear @s furnace{display:{Name:'[{"text":"Emerald Forge","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s bought_forge4 run clear @s furnace{display:{Name:'[{"text":"Molten Forge","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s forge_max run clear @s furnace{display:{Name:'[{"text":"Forge (MAX)","italic":false,"color":"red"}]'},HideFlags:2} 1

execute as @a at @s store success score @s bought_heal_pool run clear @s beacon{display:{Name:'[{"text":"Heal Pool","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s already_own_heal_pool run clear @s beacon{display:{Name:'[{"text":"Heal Pool","italic":false,"color":"green"}]'},HideFlags:2} 1

execute as @a at @s store success score @s bought_maniac1 run clear @s golden_pickaxe{display:{Name:'[{"text":"Maniac Miner I","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s bought_maniac2 run clear @s golden_pickaxe{display:{Name:'[{"text":"Maniac Miner II","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s maniac_max run clear @s golden_pickaxe{display:{Name:'[{"text":"Maniac Miner (MAX)","italic":false,"color":"red"}]'},HideFlags:2} 1


execute as @a at @s store success score @s bought_its_a_trap run clear @s tripwire_hook{display:{Name:'[{"text":"It\'s a trap!","italic":false,"color":"red"}]'},HideFlags:2} 
execute as @a at @s store success score @s bought_co_trap run clear @s feather{display:{Name:'[{"text":"Counter-Offensive Trap","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s bought_alarm_trap run clear @s redstone_torch{display:{Name:'[{"text":"Alarm Trap","italic":false,"color":"red"}]'},HideFlags:2} 1
execute as @a at @s store success score @s bought_miner_trap run clear @s iron_pickaxe{display:{Name:'[{"text":"Miner Fatigue Trap","italic":false,"color":"red"}]'},HideFlags:2} 1

##--------------------------------------------------------------------------------------------------------------
##Invalid Purchase Messages

execute as @a at @s if score @s bought_wool matches 1 if score @s iron_count matches ..3 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_endstone matches 1 if score @s iron_count matches ..23 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_wood matches 1 if score @s gold_count matches ..3 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_concrete matches 1 if score @s iron_count matches ..15 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_ladders matches 1 if score @s iron_count matches ..3 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_leaves matches 1 if score @s gold_count matches ..3 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_obby matches 1 if score @s em_count matches ..3 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_stone_sword matches 1 if score @s iron_count matches ..9 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_iron_sword matches 1 if score @s gold_count matches ..6 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_diamond_sword matches 1 if score @s em_count matches ..3 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_kb_stick matches 1 if score @s gold_count matches ..4 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_shield matches 1 if score @s gold_count matches ..3 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_rod matches 1 if score @s gold_count matches ..4 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_cannon matches 1 if score @s iron_count matches ..39 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}

execute as @a at @s if score @s bought_chain_armor matches 1 if score @s iron_count matches ..39 if score @s chainmail_armor matches 0 if score @s iron_armor matches 0 if score @s diamond_armor matches 0 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_chain_armor matches 1 if score @s iron_armor matches 1 run tellraw @s {"text":"You already have a higher level of armor!","color":"red"}
execute as @a at @s if score @s bought_chain_armor matches 1 if score @s diamond_armor matches 1 run tellraw @s {"text":"You already have a higher level of armor!","color":"red"}
execute as @a at @s if score @s bought_chain_armor matches 1 if score @s chainmail_armor matches 1 run tellraw @s {"text":"You already have this armor!","color":"red"}

execute as @a at @s if score @s bought_iron_armor matches 1 if score @s gold_count matches ..11 if score @s iron_armor matches 0 if score @s diamond_armor matches 0 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_iron_armor matches 1 if score @s iron_armor matches 1 run tellraw @s {"text":"You already have this armor!","color":"red"}
execute as @a at @s if score @s bought_iron_armor matches 1 if score @s diamond_armor matches 1 run tellraw @s {"text":"You already have a higher level of armor!","color":"red"}

execute as @a at @s if score @s bought_dia_armor matches 1 if score @s em_count matches ..5 if score @s diamond_armor matches 0 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_dia_armor matches 1 if score @s diamond_armor matches 1 run tellraw @s {"text":"You already have this armor!","color":"red"}

execute as @a at @s if score @s bought_wooden_axe matches 1 if score @s wooden_axe_count matches 1 run tellraw @s {"text":"You already have this axe!","color":"red"}
execute as @a at @s if score @s bought_wooden_axe matches 1 if score @s stone_axe_count matches 1 run tellraw @s {"text":"You already have a higher level axe!","color":"red"}
execute as @a at @s if score @s bought_wooden_axe matches 1 if score @s iron_axe_count matches 1 run tellraw @s {"text":"You already have a higher level axe!","color":"red"}
execute as @a at @s if score @s bought_wooden_axe matches 1 if score @s diamond_axe_count matches 1 run tellraw @s {"text":"You already have a higher level axe!","color":"red"}
execute as @a at @s if score @s bought_wooden_axe matches 1 if score @s iron_count matches ..9 if score @s wooden_axe_count matches 0 if score @s stone_axe_count matches 0 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}

execute as @a at @s if score @s bought_stone_axe matches 1 if score @s stone_axe_count matches 1 run tellraw @s {"text":"You already have this axe!","color":"red"}
execute as @a at @s if score @s bought_stone_axe matches 1 if score @s iron_axe_count matches 1 run tellraw @s {"text":"You already have a higher level axe!","color":"red"}
execute as @a at @s if score @s bought_stone_axe matches 1 if score @s diamond_axe_count matches 1 run tellraw @s {"text":"You already have a higher level axe!","color":"red"}
execute as @a at @s if score @s bought_stone_axe matches 1 if score @s wooden_axe_count matches 1 if score @s iron_count matches ..19 if score @s stone_axe_count matches 0 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_stone_axe matches 1 if score @s wooden_axe_count matches 0 if score @s iron_count matches 20.. if score @s stone_axe_count matches 0 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_stone_axe matches 1 if score @s wooden_axe_count matches 0 if score @s iron_count matches ..19 if score @s stone_axe_count matches 0 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}

execute as @a at @s if score @s bought_iron_axe matches 1 if score @s iron_axe_count matches 1 run tellraw @s {"text":"You already have this axe!","color":"red"}
execute as @a at @s if score @s bought_iron_axe matches 1 if score @s diamond_axe_count matches 1 run tellraw @s {"text":"You already have a higher level axe!","color":"red"}
execute as @a at @s if score @s bought_iron_axe matches 1 if score @s stone_axe_count matches 1 if score @s gold_count matches ..7 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_iron_axe matches 1 if score @s stone_axe_count matches 0 if score @s gold_count matches 8.. if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_iron_axe matches 1 if score @s stone_axe_count matches 0 if score @s gold_count matches ..7 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}

execute as @a at @s if score @s bought_diamond_axe matches 1 if score @s diamond_axe_count matches 1 run tellraw @s {"text":"You already have this axe!","color":"red"}
execute as @a at @s if score @s bought_diamond_axe matches 1 if score @s iron_axe_count matches 1 if score @s gold_count matches ..7 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_diamond_axe matches 1 if score @s iron_axe_count matches 0 if score @s gold_count matches 8.. if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_diamond_axe matches 1 if score @s iron_axe_count matches 0 if score @s gold_count matches ..7 if score @s diamond_axe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}


execute as @a at @s if score @s bought_wooden_pickaxe matches 1 if score @s wooden_pickaxe_count matches 1 run tellraw @s {"text":"You already have this pickaxe!","color":"red"}
execute as @a at @s if score @s bought_wooden_pickaxe matches 1 if score @s golden_pickaxe_count matches 1 run tellraw @s {"text":"You already have a higher level pickaxe!","color":"red"}
execute as @a at @s if score @s bought_wooden_pickaxe matches 1 if score @s iron_pickaxe_count matches 1 run tellraw @s {"text":"You already have a higher level pickaxe!","color":"red"}
execute as @a at @s if score @s bought_wooden_pickaxe matches 1 if score @s diamond_pickaxe_count matches 1 run tellraw @s {"text":"You already have a higher level pickaxe!","color":"red"}
execute as @a at @s if score @s bought_wooden_pickaxe matches 1 if score @s iron_count matches ..9 if score @s wooden_pickaxe_count matches 0 if score @s golden_pickaxe_count matches 0 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}

execute as @a at @s if score @s bought_golden_pickaxe matches 1 if score @s golden_pickaxe_count matches 1 run tellraw @s {"text":"You already have this pickaxe!","color":"red"}
execute as @a at @s if score @s bought_golden_pickaxe matches 1 if score @s iron_pickaxe_count matches 1 run tellraw @s {"text":"You already have a higher level pickaxe!","color":"red"}
execute as @a at @s if score @s bought_goldene_pickaxe matches 1 if score @s diamond_pickaxe_count matches 1 run tellraw @s {"text":"You already have a higher level pickaxe!","color":"red"}
execute as @a at @s if score @s bought_golden_pickaxe matches 1 if score @s wooden_pickaxe_count matches 1 if score @s iron_count matches ..19 if score @s golden_axe_count matches 0 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_golden_axe matches 1 if score @s wooden_axe_count matches 0 if score @s iron_count matches 20.. if score @s golden_axepick_count matches 0 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_golden_axe matches 1 if score @s wooden_axe_count matches 0 if score @s iron_count matches ..19 if score @s golden_axepick_count matches 0 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}

execute as @a at @s if score @s bought_iron_pickaxe matches 1 if score @s iron_pickaxe_count matches 1 run tellraw @s {"text":"You already have this pickaxe!","color":"red"}
execute as @a at @s if score @s bought_iron_pickaxe matches 1 if score @s diamond_pickaxe_count matches 1 run tellraw @s {"text":"You already have a higher level pickaxe!","color":"red"}
execute as @a at @s if score @s bought_iron_pickaxe matches 1 if score @s golden_pickaxe_count matches 1 if score @s gold_count matches ..7 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_iron_pickaxe matches 1 if score @s golden_pickaxe_count matches 0 if score @s gold_count matches 8.. if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_iron_pickaxe matches 1 if score @s golden_pickaxe_count matches 0 if score @s gold_count matches ..7 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}

execute as @a at @s if score @s bought_diamond_pickaxe matches 1 if score @s diamond_pickaxe_count matches 1 run tellraw @s {"text":"You already have this pickaxe!","color":"red"}
execute as @a at @s if score @s bought_diamond_pickaxe matches 1 if score @s iron_pickaxe_count matches 1 if score @s gold_count matches ..7 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_diamond_pickaxe matches 1 if score @s iron_pickaxe_count matches 0 if score @s gold_count matches 8.. if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}
execute as @a at @s if score @s bought_diamond_pickaxe matches 1 if score @s iron_pickaxe_count matches 0 if score @s gold_count matches ..7 if score @s diamond_pickaxe_count matches 0 run tellraw @s {"text":"You don't have enough resources","color":"red"}


execute as @a at @s if score @s bought_shears matches 1 if score @s shears matches 1 run tellraw @s {"text":"You already have that item!","color":"red"}
execute as @a at @s if score @s bought_shears matches 1 if score @s iron_count matches ..23 if score @s shears matches 0 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}

execute as @a at @s if score @s bought_flint matches 1 if score @s iron_count matches ..9 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}

execute as @a at @s if score @s bought_trident matches 1 if score @s gold_count matches ..2 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_loyalty_trident matches 1 if score @s em_count matches ..1 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_riptide_trident matches 1 if score @s em_count matches ..3 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}


execute as @a at @s if score @s bought_popup_tower matches 1 if score @s iron_count matches ..23 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_epearl matches 1 if score @s em_count matches ..3 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_bridge_egg matches 1 if score @s gold_count matches ..5 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_tnt matches 1 if score @s gold_count matches ..3 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_apple matches 1 if score @s gold_count matches ..2 run tellraw @s {"text":"You do not have enough gold to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_fireball matches 1 if score @s iron_count matches ..390 run tellraw @s {"text":"You do not have enough iron to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_golem matches 1 run tellraw @s {"text":"This feature has not been implemented yet!","color":"red"}

execute as @a at @s if score @s bought_invis matches 1 if score @s em_count matches ..1 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_jump matches 1 if score @s em_count matches ..0 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}
execute as @a at @s if score @s bought_speed matches 1 if score @s em_count matches ..0 run tellraw @s {"text":"You do not have enough emeralds to purchase this item!","color":"red"}



execute as @a[team=!red] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s already_own_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s sharpness matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}


execute as @a[team=!red] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!red] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!red] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!red] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!blue] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!blue] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!blue] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!green] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!green] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!green] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!yellow] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!yellow] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!yellow] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!gray] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!gray] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!gray] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!pink] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!pink] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!pink] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!white] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!white] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!white] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!aqua] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!aqua] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!aqua] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..15 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s prot_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s protection matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}


execute as @a[team=!red] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!red] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!red] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!red] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!blue] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!blue] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!blue] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!green] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!green] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!green] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!yellow] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!yellow] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!yellow] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!gray] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!gray] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!gray] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!pink] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!pink] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!pink] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!white] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!white] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!white] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!aqua] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!aqua] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..5 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!aqua] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..7 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s forge_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s forge matches 4 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}


execute as @a[team=!red] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s already_own_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s heal_pool matches 1 run tellraw @s {"text":"You already have this upgrade!","color":"red"}


execute as @a[team=!red] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!red] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!blue] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!green] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!yellow] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!gray] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!pink] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!white] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..1 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=!aqua] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..3 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s maniac_max matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s haste matches 2 run tellraw @s {"text":"You already have this upgrade maxed!","color":"red"}



execute as @a[team=!red] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}


execute as @a[team=!red] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}


execute as @a[team=!red] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}


execute as @a[team=!red] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=red] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=red] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!blue] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=blue] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!green] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=green] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=green] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!yellow] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=yellow] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!gray] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=gray] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!pink] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=pink] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!white] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=white] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=white] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}

execute as @a[team=!aqua] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run tellraw @s {"text":"You can only purchase team upgrades on your own island!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches ..0 if score @s trap3 matches 0 run tellraw @s {"text":"You don't have enough diamonds to purchase this!","color":"red"}
execute as @a[team=aqua] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 1.. run tellraw @s {"text":"You are already using all your trap slots!!","color":"red"}
##--------------------------------------------------------------------------------------------------------------

execute as @a at @s if score @s bought_wool matches 1 if score @s iron_count matches 4.. run function bedwars:shops/givewool
execute as @a at @s if score @s bought_endstone matches 1 if score @s iron_count matches 24.. run function bedwars:shops/giveendstone
execute as @a at @s if score @s bought_wood matches 1 if score @s gold_count matches 4.. run function bedwars:shops/givewood
execute as @a at @s if score @s bought_concrete matches 1 if score @s iron_count matches 16.. run function bedwars:shops/giveconcrete
execute as @a at @s if score @s bought_ladders matches 1 if score @s iron_count matches 4.. run function bedwars:shops/giveladders
execute as @a at @s if score @s bought_leaves matches 1 if score @s gold_count matches 4.. run function bedwars:shops/giveleaves
execute as @a at @s if score @s bought_obby matches 1 if score @s em_count matches 4.. run function bedwars:shops/giveobsidian

execute as @a at @s if score @s bought_stone_sword matches 1 if score @s iron_count matches 10.. run function bedwars:shops/givestonesword
execute as @a at @s if score @s bought_iron_sword matches 1 if score @s gold_count matches 7.. run function bedwars:shops/giveironsword
execute as @a at @s if score @s bought_diamond_sword matches 1 if score @s em_count matches 4.. run function bedwars:shops/givediamondsword
execute as @a at @s if score @s bought_kb_stick matches 1 if score @s gold_count matches 5.. run function bedwars:shops/givekbstick
execute as @a at @s if score @s bought_shield matches 1 if score @s gold_count matches 4.. run function bedwars:shops/giveshield
execute as @a at @s if score @s bought_rod matches 1 if score @s gold_count matches 10.. run function bedwars:shops/giverod
execute as @a at @s if score @s bought_cannon matches 1 if score @s iron_count matches 40.. run function bedwars:shops/givecannon

execute as @a at @s if score @s bought_chain_armor matches 1 if score @s iron_count matches 40.. if score @s diamond_armor matches 0 if score @s iron_armor matches 0 if score @s chainmail_armor matches 0 run function bedwars:shops/givechainarmor
execute as @a at @s if score @s bought_iron_armor matches 1 if score @s iron_armor matches 0 if score @s gold_count matches 12.. if score @s diamond_armor matches 0 run function bedwars:shops/giveironarmor
execute as @a at @s if score @s bought_dia_armor matches 1 if score @s diamond_armor matches 0 if score @s em_count matches 6.. run function bedwars:shops/givediaarmor

execute as @a at @s if score @s bought_wooden_axe matches 1 if score @s iron_count matches 10.. if score @s wooden_axe_count matches 0 if score @s stone_axe_count matches 0 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 run function bedwars:shops/givewoodenaxe
execute as @a at @s if score @s bought_stone_axe matches 1 if score @s iron_count matches 20.. if score @s stone_axe_count matches 0 if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 if score @s wooden_axe_count matches 1 run function bedwars:shops/givestoneaxe
execute as @a at @s if score @s bought_iron_axe matches 1 if score @s gold_count matches 8.. if score @s iron_axe_count matches 0 if score @s diamond_axe_count matches 0 if score @s stone_axe_count matches 1 run function bedwars:shops/giveironaxe
execute as @a at @s if score @s bought_diamond_axe matches 1 if score @s gold_count matches 12.. if score @s diamond_axe_count matches 0 if score @s iron_axe_count matches 1 run function bedwars:shops/givediamondaxe

execute as @a at @s if score @s bought_wooden_pickaxe matches 1 if score @s iron_count matches 10.. if score @s wooden_pickaxe_count matches 0 if score @s golden_pickaxe_count matches 0 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 run function bedwars:shops/givewoodenpickaxe
execute as @a at @s if score @s bought_golden_pickaxe matches 1 if score @s iron_count matches 20.. if score @s golden_pickaxe_count matches 0 if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 if score @s wooden_pickaxe_count matches 1 run function bedwars:shops/givegoldenpickaxe
execute as @a at @s if score @s bought_iron_pickaxe matches 1 if score @s gold_count matches 8.. if score @s iron_pickaxe_count matches 0 if score @s diamond_pickaxe_count matches 0 if score @s golden_pickaxe_count matches 1 run function bedwars:shops/giveironpickaxe
execute as @a at @s if score @s bought_diamond_pickaxe matches 1 if score @s gold_count matches 12.. if score @s diamond_pickaxe_count matches 0 if score @s iron_pickaxe_count matches 1 run function bedwars:shops/givediamondpickaxe

execute as @a at @s if score @s bought_shears matches 1 if score @s iron_count matches 10.. if score @s shears matches 0 run function bedwars:shops/giveshears
execute as @a at @s if score @s bought_flint matches 1 if score @s iron_count matches 24.. run function bedwars:shops/giveflint

execute as @a at @s if score @s bought_trident matches 1 if score @s gold_count matches 3.. run function bedwars:shops/givetrident
execute as @a at @s if score @s bought_loyalty_trident matches 1 if score @s em_count matches 2.. run function bedwars:shops/giveloyaltytrident
execute as @a at @s if score @s bought_riptide_trident matches 1 if score @s em_count matches 4.. run function bedwars:shops/giveriptidetrident

execute as @a at @s if score @s bought_popup_tower matches 1 if score @s iron_count matches 24.. run function bedwars:shops/givepopuptower
execute as @a at @s if score @s bought_tnt matches 1 if score @s gold_count matches 4.. run function bedwars:shops/givetnt
execute as @a at @s if score @s bought_fireball matches 1 if score @s iron_count matches 39.. run function bedwars:shops/givefireball
execute as @a at @s if score @s bought_epearl matches 1 if score @s em_count matches 4.. run function bedwars:shops/giveepearl
##execute as @a at @s if score @s bought_golem matches 1 if score @s iron_count matches 150.. run function bedwars:shops/givegolem
execute as @a at @s if score @s bought_apple matches 1 if score @s gold_count matches 3.. run function bedwars:shops/giveapple
execute as @a at @s if score @s bought_bridge_egg matches 1 if score @s gold_count matches 6.. run function bedwars:shops/givebridgeegg

execute as @a at @s if score @s bought_invis matches 1 if score @s em_count matches 2.. run function bedwars:shops/giveinvis
execute as @a at @s if score @s bought_jump matches 1 if score @s em_count matches 1.. run function bedwars:shops/givejump
execute as @a at @s if score @s bought_speed matches 1 if score @s em_count matches 1.. run function bedwars:shops/givespeed



execute as @a[team=red] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness
execute as @a[team=blue] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness
execute as @a[team=green] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness
execute as @a[team=yellow] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness
execute as @a[team=white] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness
execute as @a[team=aqua] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness
execute as @a[team=gray] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness
execute as @a[team=pink] at @s if score @s bought_sharpness matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givesharpness

execute as @a[team=red] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=red] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=red] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=red] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4

execute as @a[team=blue] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=blue] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=blue] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=blue] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4

execute as @a[team=green] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=green] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=green] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=green] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4

execute as @a[team=yellow] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=yellow] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=yellow] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=yellow] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4

execute as @a[team=gray] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=gray] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=gray] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=gray] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4

execute as @a[team=pink] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=pink] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=pink] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=pink] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4

execute as @a[team=white] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=white] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=white] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=white] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4

execute as @a[team=aqua] at @s if score @s bought_prot1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveprot1
execute as @a[team=aqua] at @s if score @s bought_prot2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveprot2
execute as @a[team=aqua] at @s if score @s bought_prot3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveprot3
execute as @a[team=aqua] at @s if score @s bought_prot4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveprot4


execute as @a[team=red] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=red] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=red] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=red] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4

execute as @a[team=blue] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=blue] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=blue] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=blue] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4

execute as @a[team=green] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=green] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=green] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=green] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4

execute as @a[team=yellow] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=yellow] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=yellow] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=yellow] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4

execute as @a[team=gray] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=gray] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=gray] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=gray] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4

execute as @a[team=pink] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=pink] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=pink] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=pink] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4

execute as @a[team=white] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=white] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=white] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=white] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4

execute as @a[team=aqua] at @s if score @s bought_forge1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/giveforge1
execute as @a[team=aqua] at @s if score @s bought_forge2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2
execute as @a[team=aqua] at @s if score @s bought_forge3 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 8.. run function bedwars:shops/giveforge3
execute as @a[team=aqua] at @s if score @s bought_forge4 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 16.. run function bedwars:shops/giveforge4


execute as @a[team=red] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool
execute as @a[team=blue] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool
execute as @a[team=green] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool
execute as @a[team=yellow] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool
execute as @a[team=white] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool
execute as @a[team=aqua] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool
execute as @a[team=gray] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool
execute as @a[team=pink] at @s if score @s bought_heal_pool matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 1.. run function bedwars:shops/givehealpool


execute as @a[team=red] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=red] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givemaniac2

execute as @a[team=blue] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=blue] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givemaniac2

execute as @a[team=green] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=green] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givemaniac2

execute as @a[team=yellow] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=yellow] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givemaniac2

execute as @a[team=gray] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=gray] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givemaniac2

execute as @a[team=pink] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=pink] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/giveforge2

execute as @a[team=white] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=white] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givemaniac2

execute as @a[team=aqua] at @s if score @s bought_maniac1 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 2.. run function bedwars:shops/givemaniac1
execute as @a[team=aqua] at @s if score @s bought_maniac2 matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s dia_count matches 4.. run function bedwars:shops/givemaniac2


execute as @a[team=red] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap
execute as @a[team=blue] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap
execute as @a[team=green] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap
execute as @a[team=yellow] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap
execute as @a[team=gray] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap
execute as @a[team=pink] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap
execute as @a[team=white] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap
execute as @a[team=aqua] at @s if score @s bought_its_a_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveitsatrap

execute as @a[team=red] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap
execute as @a[team=blue] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap
execute as @a[team=green] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap
execute as @a[team=yellow] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap
execute as @a[team=gray] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap
execute as @a[team=pink] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap
execute as @a[team=white] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap
execute as @a[team=aqua] at @s if score @s bought_alarm_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givealarmtrap

execute as @a[team=red] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap
execute as @a[team=blue] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap
execute as @a[team=green] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap
execute as @a[team=yellow] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap
execute as @a[team=gray] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap
execute as @a[team=pink] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap
execute as @a[team=white] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap
execute as @a[team=aqua] at @s if score @s bought_co_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/givecotrap

execute as @a[team=red] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
execute as @a[team=blue] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
execute as @a[team=green] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
execute as @a[team=yellow] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
execute as @a[team=gray] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
execute as @a[team=pink] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
execute as @a[team=white] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
execute as @a[team=aqua] at @s if score @s bought_miner_trap matches 1 if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] if score @s trap3 matches 0 if score @s dia_count matches 1.. run function bedwars:shops/giveminertrap
##------------------------------------------------------------------------------------------------------------------------
##Armor Management

execute as @a[scores={chainmail_armor=1}] at @s run function bedwars:shops/armorcheckchain
execute as @a[scores={iron_armor=1}] at @s run function bedwars:shops/armorcheckiron
execute as @a[scores={diamond_armor=1}] at @s run function bedwars:shops/armorcheckdia
execute as @a at @s run function bedwars:shops/armorcheckteam


execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=0,invis=0}] armor.legs with minecraft:chainmail_leggings
execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=0,invis=0},tag=!launched] armor.feet with minecraft:chainmail_boots
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=0,invis=0}] armor.legs with minecraft:iron_leggings
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=0,invis=0},tag=!launched] armor.feet with minecraft:iron_boots
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=0,invis=0}] armor.legs with minecraft:diamond_leggings
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=0,invis=0},tag=!launched] armor.feet with minecraft:diamond_boots

execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=1,invis=0}] armor.legs with minecraft:chainmail_leggings{Enchantments:[{id:protection,lvl:1}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=1,invis=0},tag=!launched] armor.feet with minecraft:chainmail_boots{Enchantments:[{id:protection,lvl:1}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=1,invis=0}] armor.legs with minecraft:iron_leggings{Enchantments:[{id:protection,lvl:1}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=1,invis=0},tag=!launched] armor.feet with minecraft:iron_boots{Enchantments:[{id:protection,lvl:1}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=1,invis=0}] armor.legs with minecraft:diamond_leggings{Enchantments:[{id:protection,lvl:1}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=1,invis=0},tag=!launched] armor.feet with minecraft:diamond_boots{Enchantments:[{id:protection,lvl:1}]}

execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=2,invis=0}] armor.legs with minecraft:chainmail_leggings{Enchantments:[{id:protection,lvl:2}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=2,invis=0},tag=!launched] armor.feet with minecraft:chainmail_boots{Enchantments:[{id:protection,lvl:2}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=2,invis=0}] armor.legs with minecraft:iron_leggings{Enchantments:[{id:protection,lvl:2}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=2,invis=0},tag=!launched] armor.feet with minecraft:iron_boots{Enchantments:[{id:protection,lvl:2}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=2,invis=0}] armor.legs with minecraft:diamond_leggings{Enchantments:[{id:protection,lvl:2}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=2,invis=0},tag=!launched] armor.feet with minecraft:diamond_boots{Enchantments:[{id:protection,lvl:2}]}

execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=3,invis=0}] armor.legs with minecraft:chainmail_leggings{Enchantments:[{id:protection,lvl:3}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=3,invis=0},tag=!launched] armor.feet with minecraft:chainmail_boots{Enchantments:[{id:protection,lvl:3}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=3,invis=0}] armor.legs with minecraft:iron_leggings{Enchantments:[{id:protection,lvl:3}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=3,invis=0},tag=!launched] armor.feet with minecraft:iron_boots{Enchantments:[{id:protection,lvl:3}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=3,invis=0}] armor.legs with minecraft:diamond_leggings{Enchantments:[{id:protection,lvl:3}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=3,invis=0},tag=!launched] armor.feet with minecraft:diamond_boots{Enchantments:[{id:protection,lvl:3}]}

execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=4,invis=0}] armor.legs with minecraft:chainmail_leggings{Enchantments:[{id:protection,lvl:4}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={chainmail_armor=1,protection=4,invis=0},tag=!launched] armor.feet with minecraft:chainmail_boots{Enchantments:[{id:protection,lvl:4}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=4,invis=0}] armor.legs with minecraft:iron_leggings{Enchantments:[{id:protection,lvl:4}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={iron_armor=1,protection=4,invis=0},tag=!launched] armor.feet with minecraft:iron_boots{Enchantments:[{id:protection,lvl:4}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=4,invis=0}] armor.legs with minecraft:diamond_leggings{Enchantments:[{id:protection,lvl:4}]}
execute if score ingame phase matches 1 run item replace entity @a[scores={diamond_armor=1,protection=4,invis=0},tag=!launched] armor.feet with minecraft:diamond_boots{Enchantments:[{id:protection,lvl:4}]}

execute if score ingame phase matches 1 run item replace entity @a[team=blue,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:3949738},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=blue,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:3949738},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=red,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:15667474},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=red,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:15667474},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=green,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:8439583},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=green,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:8439583},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=yellow,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:16701501},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=yellow,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:16701501},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=aqua,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:54227},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=aqua,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:54227},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=white,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:16383998},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=white,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:16383998},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=gray,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:4673362},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=gray,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:4673362},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=pink,scores={invis=0}] armor.head with leather_helmet{Unbreakable:1,display:{color:15961002},HideFlags:103} 1
execute if score ingame phase matches 1 run item replace entity @a[team=pink,scores={invis=0}] armor.chest with leather_chestplate{Unbreakable:1,display:{color:15961002},HideFlags:103} 1

##------------------------------------------------------------------------------------------------------------------------
##Tool Management

execute if score ingame phase matches 1 as @a store result score @s wooden_axe run clear @s minecraft:wooden_axe 0
execute if score ingame phase matches 1 as @a[scores={wooden_axe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:wooden_axe"}]}] run give @s wooden_axe{Unbreakable:1,display:{Name:'[{"text":"Wooden Axe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={wooden_axe_count=1}] at @s if score @s wooden_axe matches 2 run clear @s wooden_axe{Unbreakable:1,display:{Name:'[{"text":"Wooden Axe","italic":false,"color":"green"}]'},HideFlags:103} 1

execute if score ingame phase matches 1 as @a store result score @s stone_axe run clear @s minecraft:stone_axe 0
execute if score ingame phase matches 1 as @a[scores={stone_axe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:stone_axe"}]}] run give @s stone_axe{Unbreakable:1,display:{Name:'[{"text":"Stone Axe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={stone_axe_count=1}] at @s if score @s stone_axe matches 2 run clear @s stone_axe{Unbreakable:1,display:{Name:'[{"text":"Stone Axe","italic":false,"color":"green"}]'},HideFlags:103} 1

execute if score ingame phase matches 1 as @a store result score @s iron_axe run clear @s minecraft:iron_axe 0
execute if score ingame phase matches 1 as @a[scores={iron_axe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:iron_axe"}]}] run give @s iron_axe{Unbreakable:1,display:{Name:'[{"text":"Iron Axe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={iron_axe_count=1}] at @s if score @s iron_axe matches 2 run clear @s iron_axe{Unbreakable:1,display:{Name:'[{"text":"Iron Axe","italic":false,"color":"green"}]'},HideFlags:103} 1

execute if score ingame phase matches 1 as @a store result score @s diamond_axe run clear @s minecraft:diamond_axe 0
execute if score ingame phase matches 1 as @a[scores={diamond_axe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_axe"}]}] run give @s diamond_axe{Unbreakable:1,display:{Name:'[{"text":"Diamond Axe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={diamond_axe_count=1}] at @s if score @s diamond_axe matches 2 run clear @s diamond_axe{Unbreakable:1,display:{Name:'[{"text":"Diamond Axe","italic":false,"color":"green"}]'},HideFlags:103} 1


execute if score ingame phase matches 1 as @a store result score @s wooden_pick run clear @s minecraft:wooden_pickaxe 0
execute if score ingame phase matches 1 as @a[scores={wooden_pickaxe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:wooden_pickaxe"}]}] run give @s wooden_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Wooden Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={wooden_pickaxe_count=1}] at @s if score @s wooden_pick matches 2 run clear @s wooden_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Wooden Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1

execute if score ingame phase matches 1 as @a store result score @s golden_pick run clear @s minecraft:golden_pickaxe 0
execute if score ingame phase matches 1 as @a[scores={golden_pickaxe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:golden_pickaxe"}]}] run give @s golden_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Golden Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={golden_pickaxe_count=1}] at @s if score @s golden_pick matches 2 run clear @s golden_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Golden Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1

execute if score ingame phase matches 1 as @a store result score @s iron_pick run clear @s minecraft:iron_pickaxe 0
execute if score ingame phase matches 1 as @a[scores={iron_pickaxe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:iron_pickaxe"}]}] run give @s iron_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Iron Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={iron_pickaxe_count=1}] at @s if score @s iron_pick matches 2 run clear @s iron_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Iron Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1

execute if score ingame phase matches 1 as @a store result score @s diamond_pick run clear @s minecraft:diamond_pickaxe 0
execute if score ingame phase matches 1 as @a[scores={diamond_pickaxe_count=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_pickaxe"}]}] run give @s diamond_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Diamond Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={diamond_pickaxe_count=1}] at @s if score @s diamond_pick matches 2 run clear @s diamond_pickaxe{Unbreakable:1,display:{Name:'[{"text":"Diamond Pickaxe","italic":false,"color":"green"}]'},HideFlags:103} 1


execute if score ingame phase matches 1 as @a store result score @s shears_count run clear @s minecraft:shears 0
execute if score ingame phase matches 1 as @a[scores={shears=1}] at @s unless entity @s[nbt={Inventory:[{id:"minecraft:shears"}]}] run give @s shears{Unbreakable:1,display:{Name:'[{"text":"Shears","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a[scores={shears=1}] at @s if score @s shears_count matches 2 run clear @s shears{Unbreakable:1,display:{Name:'[{"text":"Shears","italic":false,"color":"green"}]'},HideFlags:103} 1

execute if score ingame phase matches 1 as @a store result score @s wood_sword run clear @s minecraft:wooden_sword 0
execute if score ingame phase matches 1 as @a at @s unless entity @s[nbt={Inventory:[{id:"minecraft:wooden_sword"}]}] unless entity @s[nbt={Inventory:[{id:"minecraft:stone_sword"}]}] unless entity @s[nbt={Inventory:[{id:"minecraft:iron_sword"}]}] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword"}]}] run give @s wooden_sword{Unbreakable:1,display:{Name:'[{"text":"Wooden Sword","italic":false,"color":"green"}]'},HideFlags:103} 1
execute if score ingame phase matches 1 as @a at @s if score @s wood_sword matches 2 run clear @s wooden_sword{Unbreakable:1,display:{Name:'[{"text":"Wooden Sword","italic":false,"color":"green"}]'},HideFlags:103} 1


##Upgrade Management

effect give @a[scores={haste=1}] minecraft:haste infinite 1 true
effect give @a[scores={haste=2}] minecraft:haste infinite 2 true
enchant @a[scores={sharpness=1}] minecraft:sharpness 1

execute if entity @a[scores={heal_pool=1},team=aqua] as @e[type=minecraft:armor_stand,tag=aqua_heal_pool] at @s run effect give @a[team=aqua,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=aqua] as @e[type=minecraft:armor_stand,tag=aqua_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force
execute if entity @a[scores={heal_pool=1},team=white] as @e[type=minecraft:armor_stand,tag=white_heal_pool] at @s run effect give @a[team=white,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=white] as @e[type=minecraft:armor_stand,tag=white_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force
execute if entity @a[scores={heal_pool=1},team=red] as @e[type=minecraft:armor_stand,tag=red_heal_pool] at @s run effect give @a[team=red,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=red] as @e[type=minecraft:armor_stand,tag=red_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force
execute if entity @a[scores={heal_pool=1},team=blue] as @e[type=minecraft:armor_stand,tag=blue_heal_pool] at @s run effect give @a[team=blue,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=blue] as @e[type=minecraft:armor_stand,tag=blue_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force
execute if entity @a[scores={heal_pool=1},team=green] as @e[type=minecraft:armor_stand,tag=green_heal_pool] at @s run effect give @a[team=green,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=green] as @e[type=minecraft:armor_stand,tag=green_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force
execute if entity @a[scores={heal_pool=1},team=yellow] as @e[type=minecraft:armor_stand,tag=yellow_heal_pool] at @s run effect give @a[team=yellow,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=yellow] as @e[type=minecraft:armor_stand,tag=yellow_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force
execute if entity @a[scores={heal_pool=1},team=gray] as @e[type=minecraft:armor_stand,tag=gray_heal_pool] at @s run effect give @a[team=gray,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=gray] as @e[type=minecraft:armor_stand,tag=gray_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force
execute if entity @a[scores={heal_pool=1},team=pink] as @e[type=minecraft:armor_stand,tag=pink_heal_pool] at @s run effect give @a[team=pink,distance=..6] minecraft:regeneration 1 4 true
execute if entity @a[scores={heal_pool=1},team=pink] as @e[type=minecraft:armor_stand,tag=pink_heal_pool] at @s run particle minecraft:happy_villager ~ ~ ~ 6 6 6 1 3 force




execute if score @e[type=minecraft:chest_minecart,limit=1,tag=gray_team_shop] forge matches 0 run scoreboard players set @e[tag=gray_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=gray_team_shop] forge matches 1 run scoreboard players set @e[tag=gray_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=gray_team_shop] forge matches 2 run scoreboard players set @e[tag=gray_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=gray_team_shop] forge matches 3 run scoreboard players set @e[tag=gray_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=gray_team_shop] forge matches 4 run scoreboard players set @e[tag=gray_team_gen,type=minecraft:armor_stand] forge 4

execute if score @e[type=minecraft:chest_minecart,limit=1,tag=pink_team_shop] forge matches 0 run scoreboard players set @e[tag=pink_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=pink_team_shop] forge matches 1 run scoreboard players set @e[tag=pink_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=pink_team_shop] forge matches 2 run scoreboard players set @e[tag=pink_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=pink_team_shop] forge matches 3 run scoreboard players set @e[tag=pink_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=pink_team_shop] forge matches 4 run scoreboard players set @e[tag=pink_team_gen,type=minecraft:armor_stand] forge 4

execute if score @e[type=minecraft:chest_minecart,limit=1,tag=red_team_shop] forge matches 0 run scoreboard players set @e[tag=red_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=red_team_shop] forge matches 1 run scoreboard players set @e[tag=red_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=red_team_shop] forge matches 2 run scoreboard players set @e[tag=red_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=red_team_shop] forge matches 3 run scoreboard players set @e[tag=red_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=red_team_shop] forge matches 4 run scoreboard players set @e[tag=red_team_gen,type=minecraft:armor_stand] forge 4

execute if score @e[type=minecraft:chest_minecart,limit=1,tag=blue_team_shop] forge matches 0 run scoreboard players set @e[tag=blue_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=blue_team_shop] forge matches 1 run scoreboard players set @e[tag=blue_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=blue_team_shop] forge matches 2 run scoreboard players set @e[tag=blue_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=blue_team_shop] forge matches 3 run scoreboard players set @e[tag=blue_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=blue_team_shop] forge matches 4 run scoreboard players set @e[tag=blue_team_gen,type=minecraft:armor_stand] forge 4

execute if score @e[type=minecraft:chest_minecart,limit=1,tag=green_team_shop] forge matches 0 run scoreboard players set @e[tag=green_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=green_team_shop] forge matches 1 run scoreboard players set @e[tag=green_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=green_team_shop] forge matches 2 run scoreboard players set @e[tag=green_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=green_team_shop] forge matches 3 run scoreboard players set @e[tag=green_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=green_team_shop] forge matches 4 run scoreboard players set @e[tag=green_team_gen,type=minecraft:armor_stand] forge 4

execute if score @e[type=minecraft:chest_minecart,limit=1,tag=yellow_team_shop] forge matches 0 run scoreboard players set @e[tag=yellow_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=yellow_team_shop] forge matches 1 run scoreboard players set @e[tag=yellow_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=yellow_team_shop] forge matches 2 run scoreboard players set @e[tag=yellow_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=yellow_team_shop] forge matches 3 run scoreboard players set @e[tag=yellow_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=yellow_team_shop] forge matches 4 run scoreboard players set @e[tag=yellow_team_gen,type=minecraft:armor_stand] forge 4

execute if score @e[type=minecraft:chest_minecart,limit=1,tag=white_team_shop] forge matches 0 run scoreboard players set @e[tag=white_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=white_team_shop] forge matches 1 run scoreboard players set @e[tag=white_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=white_team_shop] forge matches 2 run scoreboard players set @e[tag=white_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=white_team_shop] forge matches 3 run scoreboard players set @e[tag=white_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=white_team_shop] forge matches 4 run scoreboard players set @e[tag=white_team_gen,type=minecraft:armor_stand] forge 4

execute if score @e[type=minecraft:chest_minecart,limit=1,tag=aqua_team_shop] forge matches 0 run scoreboard players set @e[tag=aqua_team_gen,type=minecraft:armor_stand] forge 0
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=aqua_team_shop] forge matches 1 run scoreboard players set @e[tag=aqua_team_gen,type=minecraft:armor_stand] forge 1
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=aqua_team_shop] forge matches 2 run scoreboard players set @e[tag=aqua_team_gen,type=minecraft:armor_stand] forge 2
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=aqua_team_shop] forge matches 3 run scoreboard players set @e[tag=aqua_team_gen,type=minecraft:armor_stand] forge 3
execute if score @e[type=minecraft:chest_minecart,limit=1,tag=aqua_team_shop] forge matches 4 run scoreboard players set @e[tag=aqua_team_gen,type=minecraft:armor_stand] forge 4


execute as @e[type=minecraft:armor_stand,tag=diagen_display] at @s run tp @s ~ ~ ~ ~3 ~
execute as @e[type=minecraft:armor_stand,tag=emgen_display] at @s run tp @s ~ ~ ~ ~3 ~

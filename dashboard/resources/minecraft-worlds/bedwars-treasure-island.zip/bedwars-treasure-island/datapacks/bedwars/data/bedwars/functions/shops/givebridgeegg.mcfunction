give @s egg{display:{Name:'[{"text":"Cloud Jumper","italic":false,"color":"green"}]',Lore:['[{"text":"Right-Click to launch into the sky","italic":false,"color":"dark_purple"}]']}} 1

clear @s gold_ingot 6

playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

item replace entity @s container.0 with minecraft:air
item replace entity @s container.1 with minecraft:air
item replace entity @s container.2 with minecraft:air
item replace entity @s container.3 with minecraft:air
item replace entity @s container.4 with minecraft:air
item replace entity @s container.5 with minecraft:air
item replace entity @s container.6 with minecraft:air
item replace entity @s container.7 with minecraft:air
item replace entity @s container.8 with minecraft:air
item replace entity @s container.9 with minecraft:air
item replace entity @s container.10 with minecraft:air
item replace entity @s container.11 with minecraft:air
item replace entity @s container.12 with trident{Unbreakable:1,display:{Name:'[{"text":"Trident","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"3 Gold","color":"gold"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},HideFlags:102} 1
item replace entity @s container.13 with trident{Unbreakable:1,display:{Name:'[{"text":"Trident (Loyalty I)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"2 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{id:loyalty,lvl:1}],HideFlags:103} 1
item replace entity @s container.14 with trident{Unbreakable:1,display:{Name:'[{"text":"Trident (Riptide II)","italic":false,"color":"green"}]',Lore:['[{"text":"Cost: ","italic":false,"color":"gray"},{"text":"4 Emeralds","color":"dark_green"},{"text":"","color":"dark_purple"}]','[{"text":"","italic":false,"color":"dark_purple"}]','[{"text":"Click to Purchase!","italic":false,"color":"yellow"}]']},Enchantments:[{id:riptide,lvl:2}],HideFlags:103} 1
item replace entity @s container.15 with minecraft:air
item replace entity @s container.16 with minecraft:air
item replace entity @s container.17 with minecraft:air
item replace entity @s container.19 with minecraft:air
item replace entity @s container.20 with minecraft:air
item replace entity @s container.21 with minecraft:air
item replace entity @s container.22 with minecraft:air
item replace entity @s container.23 with minecraft:air
item replace entity @s container.24 with minecraft:air
item replace entity @s container.25 with minecraft:air
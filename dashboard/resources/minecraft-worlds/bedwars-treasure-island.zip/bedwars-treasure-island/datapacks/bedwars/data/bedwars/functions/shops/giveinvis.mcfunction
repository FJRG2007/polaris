give @s potion{CustomPotionColor:10322096,display:{Name:'[{"text":"Invisibility Potion (30s)","italic":false,"color":"green"}]'},Enchantments:[{}],HideFlags:3,CustomPotionEffects:[{Id:14,Duration:600,Amplifier:1,ShowParticles:0b}]}

clear @s emerald 2
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

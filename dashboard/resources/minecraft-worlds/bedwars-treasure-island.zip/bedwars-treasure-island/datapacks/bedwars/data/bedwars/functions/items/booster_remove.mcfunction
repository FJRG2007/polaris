effect clear @a[tag=launched] levitation
schedule function bedwars:items/booster_fall_damage 4s
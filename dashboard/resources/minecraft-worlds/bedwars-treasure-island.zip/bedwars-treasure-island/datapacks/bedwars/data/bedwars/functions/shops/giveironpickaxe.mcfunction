scoreboard players set @s golden_pickaxe_count 0
clear @s golden_pickaxe
scoreboard players set @s iron_pickaxe_count 1
clear @s gold_ingot 8
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

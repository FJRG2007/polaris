execute as @a[scores={leaves_placed=1}] at @s run summon minecraft:armor_stand ^ ^ ^ {Invulnerable:1,Invisible:1,Silent:1,Tags:["leafscan1"],NoGravity:1}
execute as @a[scores={leaves_placed=1}] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=leafscan1] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=leafscan1] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["leafscan2"],Silent:1,NoGravity:1}
execute as @e[tag=leafscan1,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=leafscan2] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=leafscan2] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["leafscan3"],Silent:1,NoGravity:1}
execute as @e[tag=leafscan2,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=leafscan3] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=leafscan3] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["leafscan4"],Silent:1,NoGravity:1}
execute as @e[tag=leafscan3,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=leafscan4] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=leafscan4] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["leafscan5"],Silent:1,NoGravity:1}
execute as @e[tag=leafscan4,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=leafscan5] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=leafscan5] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["leafscan6"],Silent:1,NoGravity:1}
execute as @e[tag=leafscan5,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=leafscan6] Rotation set from entity @s Rotation
execute as @e[type=armor_stand,tag=leafscan1] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["leafscan1"]}
execute as @e[type=armor_stand,tag=leafscan2] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["leafscan2"]}
execute as @e[type=armor_stand,tag=leafscan3] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["leafscan3"]}
execute as @e[type=armor_stand,tag=leafscan4] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["leafscan4"]}
execute as @e[type=armor_stand,tag=leafscan5] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["leafscan5"]}
execute as @e[type=armor_stand,tag=leafscan6] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["leafscan6"]}
execute as @e[type=minecraft:armor_stand,tag=leafscan1] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=leafscan1]
execute as @e[type=minecraft:armor_stand,tag=leafscan2] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=leafscan2]
execute as @e[type=minecraft:armor_stand,tag=leafscan3] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=leafscan3]
execute as @e[type=minecraft:armor_stand,tag=leafscan4] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=leafscan4]
execute as @e[type=minecraft:armor_stand,tag=leafscan5] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=leafscan5]
execute as @e[type=minecraft:armor_stand,tag=leafscan6] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=leafscan6]
execute as @e[type=minecraft:armor_stand,tag=leafscan1] at @s run kill @e[type=item_frame,distance=..2,tag=leafscan1]
execute as @e[type=minecraft:armor_stand,tag=leafscan2] at @s run kill @e[type=item_frame,distance=..2,tag=leafscan2]
execute as @e[type=minecraft:armor_stand,tag=leafscan3] at @s run kill @e[type=item_frame,distance=..2,tag=leafscan3]
execute as @e[type=minecraft:armor_stand,tag=leafscan4] at @s run kill @e[type=item_frame,distance=..2,tag=leafscan4]
execute as @e[type=minecraft:armor_stand,tag=leafscan5] at @s run kill @e[type=item_frame,distance=..2,tag=leafscan5]
execute as @e[type=minecraft:armor_stand,tag=leafscan6] at @s run kill @e[type=item_frame,distance=..2,tag=leafscan6]
execute as @e[tag=leafscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run setblock ~ ~ ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run setblock ~ ~1 ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ oak_leaves run setblock ~ ~2 ~ minecraft:oak_leaves[waterlogged=true]

execute as @e[tag=leafscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run setblock ~ ~ ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run setblock ~ ~1 ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ oak_leaves run setblock ~ ~2 ~ minecraft:oak_leaves[waterlogged=true]

execute as @e[tag=leafscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run setblock ~ ~ ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run setblock ~ ~1 ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ oak_leaves run setblock ~ ~2 ~ minecraft:oak_leaves[waterlogged=true]

execute as @e[tag=leafscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run setblock ~ ~ ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run setblock ~ ~1 ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ oak_leaves run setblock ~ ~2 ~ minecraft:oak_leaves[waterlogged=true]

execute as @e[tag=leafscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run setblock ~ ~ ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run setblock ~ ~1 ~ minecraft:oak_leaves[waterlogged=true]
execute as @e[tag=leafscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ oak_leaves run setblock ~ ~2 ~ minecraft:oak_leaves[waterlogged=true]

kill @e[type=armor_stand,tag=leafscan1]
kill @e[type=armor_stand,tag=leafscan2]
kill @e[type=armor_stand,tag=leafscan3]
kill @e[type=armor_stand,tag=leafscan4]
kill @e[type=armor_stand,tag=leafscan5]
kill @e[type=armor_stand,tag=leafscan6]
scoreboard players set @a leaves_placed 0
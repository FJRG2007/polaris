execute if score playercount playercount matches 0 run team modify playercount suffix {"text":" 0"}
execute if score playercount playercount matches 1 run team modify playercount suffix {"text":" 1"}
execute if score playercount playercount matches 2 run team modify playercount suffix {"text":" 2"}
execute if score playercount playercount matches 3 run team modify playercount suffix {"text":" 3"}
execute if score playercount playercount matches 4 run team modify playercount suffix {"text":" 4"}
execute if score playercount playercount matches 5 run team modify playercount suffix {"text":" 5"}
execute if score playercount playercount matches 6 run team modify playercount suffix {"text":" 6"}
execute if score playercount playercount matches 7 run team modify playercount suffix {"text":" 7"}
execute if score playercount playercount matches 8 run team modify playercount suffix {"text":" 8"}
execute if score playercount playercount matches 9 run team modify playercount suffix {"text":" 9"}
execute if score playercount playercount matches 10 run team modify playercount suffix {"text":" 10"}
execute if score playercount playercount matches 11 run team modify playercount suffix {"text":" 11"}
execute if score playercount playercount matches 12 run team modify playercount suffix {"text":" 12"}
execute if score playercount playercount matches 13 run team modify playercount suffix {"text":" 13"}
execute if score playercount playercount matches 14 run team modify playercount suffix {"text":" 14"}
execute if score playercount playercount matches 15 run team modify playercount suffix {"text":" 15"}
execute if score playercount playercount matches 16 run team modify playercount suffix {"text":" 16"}
execute if score playercount playercount matches 17.. run team modify playercount suffix {"text":" 17+ (TOO MANY!)"}
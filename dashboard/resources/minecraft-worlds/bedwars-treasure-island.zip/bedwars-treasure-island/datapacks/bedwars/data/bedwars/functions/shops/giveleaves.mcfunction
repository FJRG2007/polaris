give @s oak_leaves{Unbreakable:1,display:{Name:'[{"text":"Waterlogged Leaves","italic":false}]'},HideFlags:6,Null:0b} 2

clear @s gold_ingot 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

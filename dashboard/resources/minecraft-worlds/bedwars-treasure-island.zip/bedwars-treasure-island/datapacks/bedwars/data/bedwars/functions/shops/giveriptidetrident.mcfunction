give @s trident{Unbreakable:1,display:{Name:'[{"text":"Trident (Riptide II)","italic":false,"color":"green"}]'},Enchantments:[{id:riptide,lvl:2}],HideFlags:103} 1

clear @s emerald 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

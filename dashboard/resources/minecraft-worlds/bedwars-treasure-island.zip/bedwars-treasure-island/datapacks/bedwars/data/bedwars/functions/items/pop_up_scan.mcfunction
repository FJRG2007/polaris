execute as @a[scores={popup_placed=1}] at @s run summon minecraft:armor_stand ^ ^ ^ {Invulnerable:1,Invisible:1,Silent:1,Tags:["popupscan1"],NoGravity:1}
execute as @a[scores={popup_placed=1}] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=popupscan1] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=popupscan1] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["popupscan2"],Silent:1,NoGravity:1}
execute as @e[tag=popupscan1,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=popupscan2] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=popupscan2] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["popupscan3"],Silent:1,NoGravity:1}
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=popupscan3] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=popupscan3] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["popupscan4"],Silent:1,NoGravity:1}
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=popupscan4] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=popupscan4] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["popupscan5"],Silent:1,NoGravity:1}
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=popupscan5] Rotation set from entity @s Rotation
execute as @e[type=minecraft:armor_stand,tag=popupscan5] at @s run summon minecraft:armor_stand ^ ^ ^1 {Invulnerable:1,Invisible:1,Tags:["popupscan6"],Silent:1,NoGravity:1}
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s run data modify entity @e[type=minecraft:armor_stand,distance=..1,limit=1,tag=popupscan6] Rotation set from entity @s Rotation
execute as @e[type=armor_stand,tag=popupscan1] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["popupscan1"]}
execute as @e[type=armor_stand,tag=popupscan2] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["popupscan2"]}
execute as @e[type=armor_stand,tag=popupscan3] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["popupscan3"]}
execute as @e[type=armor_stand,tag=popupscan4] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["popupscan4"]}
execute as @e[type=armor_stand,tag=popupscan5] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["popupscan5"]}
execute as @e[type=armor_stand,tag=popupscan6] at @s run summon item_frame ~ ~ ~ {Invulnerable:1,Invisible:1,Tags:["popupscan6"]}
execute as @e[type=minecraft:armor_stand,tag=popupscan1] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=popupscan1]
execute as @e[type=minecraft:armor_stand,tag=popupscan2] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=popupscan2]
execute as @e[type=minecraft:armor_stand,tag=popupscan3] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=popupscan3]
execute as @e[type=minecraft:armor_stand,tag=popupscan4] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=popupscan4]
execute as @e[type=minecraft:armor_stand,tag=popupscan5] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=popupscan5]
execute as @e[type=minecraft:armor_stand,tag=popupscan6] at @s run tp @s @e[type=item_frame,limit=1,sort=nearest,distance=..2,tag=popupscan6]
execute as @e[type=minecraft:armor_stand,tag=popupscan1] at @s run kill @e[type=item_frame,distance=..2,tag=popupscan1]
execute as @e[type=minecraft:armor_stand,tag=popupscan2] at @s run kill @e[type=item_frame,distance=..2,tag=popupscan2]
execute as @e[type=minecraft:armor_stand,tag=popupscan3] at @s run kill @e[type=item_frame,distance=..2,tag=popupscan3]
execute as @e[type=minecraft:armor_stand,tag=popupscan4] at @s run kill @e[type=item_frame,distance=..2,tag=popupscan4]
execute as @e[type=minecraft:armor_stand,tag=popupscan5] at @s run kill @e[type=item_frame,distance=..2,tag=popupscan5]
execute as @e[type=minecraft:armor_stand,tag=popupscan6] at @s run kill @e[type=item_frame,distance=..2,tag=popupscan6]
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan2,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:wool

execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan3,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:wool

execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan4,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:wool

execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan5,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:wool

execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~ ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~ ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~1 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~1 ~-4 filtered #minecraft:wool
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:stairs
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered minecraft:ladder
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:banners
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:trapdoors
execute as @e[tag=popupscan6,type=minecraft:armor_stand] at @s if block ~ ~2 ~ note_block run clone -117 125 -472 -125 135 -480 ~-4 ~2 ~-4 filtered #minecraft:wool

kill @e[type=armor_stand,tag=popupscan1]
kill @e[type=armor_stand,tag=popupscan2]
kill @e[type=armor_stand,tag=popupscan3]
kill @e[type=armor_stand,tag=popupscan4]
kill @e[type=armor_stand,tag=popupscan5]
kill @e[type=armor_stand,tag=popupscan6]
scoreboard players set @a popup_placed 0
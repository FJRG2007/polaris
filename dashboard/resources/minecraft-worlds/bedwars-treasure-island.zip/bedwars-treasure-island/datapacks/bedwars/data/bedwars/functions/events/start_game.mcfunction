scoreboard players reset @a redBedBroken
scoreboard players reset @a blueBedBroken
scoreboard players reset @a greenBedBroken
scoreboard players reset @a yellowBedBroken
scoreboard players reset @a whiteBedBroken
scoreboard players reset @a aquaBedBroken
scoreboard players reset @a pinkBedBroken
scoreboard players reset @a grayBedBroken
scoreboard players set white beds 1
scoreboard players set aqua beds 1
scoreboard players set gray beds 1
scoreboard players set pink beds 1
scoreboard players set yellow beds 1
scoreboard players set red beds 1
scoreboard players set green beds 1
scoreboard players set blue beds 1
tag @a add player
scoreboard players set pregame phase 0
scoreboard players set ingame phase 1
function bedwars:events/resetupgrades
function bedwars:events/resettools
function bedwars:events/resetarmor
clear @a

setblock 91 62 -27 air
setblock 91 62 33 air
setblock 27 62 91 air
setblock -33 62 91 air
setblock -91 62 27 air
setblock -91 62 -33 air
setblock -27 62 -91 air
setblock 33 62 -91 air

kill @e[type=item]

tp @a[team=yellow] 98 61 30 90 0
tp @a[team=green] 98 61 -30 90 0
tp @a[team=aqua] 30 61 98 -180 0
tp @a[team=white] -30 61 98 -180 0
tp @a[team=light_purple] -98 61 30 -90 0
tp @a[team=gray] -98 61 -30 -90 0
tp @a[team=red] -30 61 -98 0 0
tp @a[team=blue] 30 61 -98 0 0
schedule function bedwars:lobby/clearlobby 1t
scoreboard players set RedTeamGen generator_level 1
scoreboard players set BlueTeamGen generator_level 1
scoreboard players set WhiteTeamGen generator_level 1
scoreboard players set AquaTeamGen generator_level 1
scoreboard players set PinkTeamGen generator_level 1
scoreboard players set GrayTeamGen generator_level 1
scoreboard players set GreenTeamGen generator_level 1
scoreboard players set YellowTeamGen generator_level 1
scoreboard players set DiaGen generator_level 1
scoreboard players set EmGen generator_level 1
function bedwars:events/start_phases
function bedwars:events/startteamgens
clone -112 66 -452 -100 81 -464 8 57 -77
clone -112 66 -452 -100 81 -464 -21 57 -77
clone -112 66 -452 -100 81 -464 -6 65 -56
clone -112 66 -452 -100 81 -464 65 57 -21
clone -112 66 -452 -100 81 -464 65 57 8
clone -112 66 -452 -100 81 -464 44 65 -6
clone -112 66 -452 -100 81 -464 9 57 65
clone -112 66 -452 -100 81 -464 -20 57 65
clone -112 66 -452 -100 81 -464 -6 65 44
clone -112 66 -452 -100 81 -464 -56 65 -6
clone -112 66 -452 -100 81 -464 -77 57 -21
clone -112 66 -452 -100 81 -464 -77 57 9
gamemode survival @a
scoreboard players set border shrinking 0
function bedwars:events/reset_bed_messages
tag @a remove Eliminated
title @a subtitle {"text":"Be the last team standing","color":"dark_green"}
title @a title {"text":"Fight!","color":"green"}
scoreboard players set red eliminated 0
scoreboard players set blue eliminated 0
scoreboard players set green eliminated 0
scoreboard players set yellow eliminated 0
scoreboard players set gray eliminated 0
scoreboard players set pink eliminated 0
scoreboard players set white eliminated 0
scoreboard players set aqua eliminated 0
scoreboard players set gameover gameover 0
item replace entity @a enderchest.0 with air
item replace entity @a enderchest.1 with air
item replace entity @a enderchest.2 with air
item replace entity @a enderchest.3 with air
item replace entity @a enderchest.4 with air
item replace entity @a enderchest.5 with air
item replace entity @a enderchest.6 with air
item replace entity @a enderchest.7 with air
item replace entity @a enderchest.8 with air
item replace entity @a enderchest.9 with air
item replace entity @a enderchest.10 with air
item replace entity @a enderchest.11 with air
item replace entity @a enderchest.12 with air
item replace entity @a enderchest.13 with air
item replace entity @a enderchest.14 with air
item replace entity @a enderchest.15 with air
item replace entity @a enderchest.16 with air
item replace entity @a enderchest.17 with air
item replace entity @a enderchest.18 with air
item replace entity @a enderchest.19 with air
item replace entity @a enderchest.20 with air
item replace entity @a enderchest.21 with air
item replace entity @a enderchest.22 with air
item replace entity @a enderchest.23 with air
item replace entity @a enderchest.24 with air
item replace entity @a enderchest.25 with air
item replace entity @a enderchest.26 with air
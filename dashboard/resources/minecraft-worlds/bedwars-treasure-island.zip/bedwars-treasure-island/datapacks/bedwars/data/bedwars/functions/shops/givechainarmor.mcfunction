scoreboard players set @s chainmail_armor 1
clear @s iron_ingot 40
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

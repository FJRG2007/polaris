execute as @a[tag=closed_blue_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_blue_shop] barrier

clear @a barrier

tag @a[tag=closed_blue_shop] remove closed_blue_shop
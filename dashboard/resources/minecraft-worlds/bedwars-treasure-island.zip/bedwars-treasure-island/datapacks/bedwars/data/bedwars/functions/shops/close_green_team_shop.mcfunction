execute as @e[tag=green_team_shop,type=minecraft:chest_minecart] at @s run tag @a[distance=..6.9] add closed_green_team_shop

execute as @a[tag=closed_green_team_shop] at @s run tp @s ~ ~30 ~

schedule function bedwars:shops/greenteamtpdown 2t

item replace entity @e[tag=green_team_shop,type=chest_minecart] container.26 with minecraft:barrier{display:{Name:'[{"text":"Close Menu","italic":false,"color":"red"}]'}}
give @s tnt{Unbreakable:1,display:{Name:'[{"text":"TNT","italic":false,"color":"green"}]'},HideFlags:103} 1

clear @s gold_ingot 4
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

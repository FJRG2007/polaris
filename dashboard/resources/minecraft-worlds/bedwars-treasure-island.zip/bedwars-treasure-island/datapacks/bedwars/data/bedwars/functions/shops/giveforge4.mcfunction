execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @a[team=red] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=red_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=red_team_shop] forge 4

execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @a[team=blue] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=blue_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=blue_team_shop] forge 4

execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @a[team=green] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=green_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=green_team_shop] forge 4

execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @a[team=yellow] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=yellow_team_shop] forge 4

execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @a[team=gray] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=gray_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=gray_team_shop] forge 4

execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @a[team=pink] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=pink_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=pink_team_shop] forge 4

execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @a[team=white] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=white_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=white_team_shop] forge 4

execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @a[team=aqua] forge 4
execute if entity @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] run scoreboard players set @e[type=chest_minecart,distance=..6,tag=aqua_team_shop] forge 4

clear @s diamond 8
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

scoreboard players set @s diamond_armor 1
scoreboard players set @s chainmail_armor 0
scoreboard players set @s iron_armor 0

clear @s emerald 6
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 2 1

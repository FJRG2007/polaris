execute as @a[tag=closed_yellow_shop] at @s run tp @s ~ ~-30 ~

clear @a[tag=closed_yellow_shop] barrier

clear @a barrier

tag @a[tag=closed_yellow_shop] remove closed_yellow_shop
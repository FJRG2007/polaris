item replace entity @s armor.feet with leather_boots[tooltip_display={hidden_components:[enchantments]},unbreakable={},custom_data={"hielkemaps:item":true},enchantments={"minecraft:binding_curse":1,"minecraft:vanishing_curse":1}]
playsound item.armor.equip_leather master @s ~ ~ ~ 1 1 1
tag @s add snow_boots
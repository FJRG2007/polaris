setblock ~ ~ ~ lava
kill @s
advancement revoke @s only more_maps:left_click
advancement revoke @s only more_maps:right_click
scoreboard players set @s view_map 0

execute at @s run playsound minecraft:block.note_block.cow_bell master @s ~ ~ ~ 0.5 1

execute if score #current_map mm_value matches 1 run tellraw @s [{text:"Hielke Maps Network:",bold:true},{text:" "},{text:"[TRAILER]",color:"red"},{text:" "},{text:"[COPY IP]",color:"blue",click_event:{action:"copy_to_clipboard",value:"play.hielkemaps.com"},hover_event:{action:"show_text",value:"Click to copy"}}]

execute if score #current_map mm_value matches 2 run tellraw @s [{text:"Parkour Spiral: ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 3 run tellraw @s [{text:"Parkour Spiral ",bold:true,color:"white"},{text:"2",bold:true,color:"yellow"},{text:": ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 4 run tellraw @s [{text:"Parkour Spiral ",bold:true,color:"white"},{text:"3",bold:true,color:"red"},{text:": ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 5 run tellraw @s [{text:"Parkour Paradise: ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 6 run tellraw @s [{text:"Parkour Paradise ",bold:true,color:"white"},{text:"2",bold:true,color:"yellow"},{text:": ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 7 run tellraw @s [{text:"Parkour Paradise ",bold:true,color:"white"},{text:"3",bold:true,color:"red"},{text:": ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 8 run tellraw @s [{text:"Dimension Parkour: ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 9 run tellraw @s [{text:"Parkour Pyramid: ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 10 run tellraw @s [{text:"Parkour Town: ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 11 run tellraw @s [{text:"Parkour Egg: ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]

execute if score #current_map mm_value matches 12 run tellraw @s [{text:"Parkour Volcano: ",bold:true,color:"white"},{text:"[LINK]",color:"blue"}]